<?php
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'init.php';
$template_file 	= SB_Request::getString('tpl_file', 'index.php');
sb_process_module(SB_Request::getString('mod', 'content'));
sb_process_template($template_file);
sb_show_template();