<?php
class SB_Session
{
	public static function start()
	{
		//session_set_cookie_params(86400);
		//ini_set('session.gc_maxlifetime', 86400);
		//$id = session_id();
		@session_start();
	}
	public static function destroy()
	{
		session_destroy();
	}
	public static function setVar($var, $value)
	{
		$_SESSION[$var] = $value;
	}
	public static function unsetVar($var)
	{
		$_SESSION[$var] = null;
		unset($_SESSION[$var]);
	}
	public static function &getVar($var, $default = null)
	{
		if( !isset($_SESSION[$var]) )
			return $default;
		
		return $_SESSION[$var];
	}
}