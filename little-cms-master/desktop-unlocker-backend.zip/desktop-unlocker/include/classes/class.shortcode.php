<?php
class SB_Shortcode
{
	protected static $tags = array();
	
	public static function AddShortcode($tag, $callback, $priority = 10)
	{
		self::$tags[$tag] = array('tag' => $tag, 'callback' => $callback, 'priority' => $priority);
	}
	public static function ParseShortcodes($string)
	{
		if( defined('LT_ADMIN') )
			return $string;
		if( !preg_match_all('/\[(\w+)(.*)\]/', $string, $matches) )
			return $string;
		$tags = $matches[1];
		$str_args = $matches[2];
		foreach($tags as $index => $tag)
		{
			if( !isset(self::$tags[$tag]) ) continue;
			$shortcode = self::$tags[$tag];
			$args = array();
			foreach(array_map('trim', explode(',', $str_args[$index])) as $p)
			{
				if( !strstr($p, '=') ) continue;
				list($k, $v) = explode('=', $p);
				$args[$k] = preg_replace('/[^a-zA-Z0-9_-]/', '', $v);
			}
			$string = str_replace($matches[0][$index], call_user_func($shortcode['callback'], $args), $string);
		}
		return $string;
	}
}