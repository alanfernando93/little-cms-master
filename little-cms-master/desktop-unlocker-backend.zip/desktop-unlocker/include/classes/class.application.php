<?php
class SB_Application
{
	protected	$defaultModules = array(
			'mod_modules',
			'mod_users',
			'mod_settings'
	);
	protected	$controller;
	protected 	$view;
	protected	$module;
	
	private function __construct()
	{
		
	}
	public function Load()
	{
		if( !is_dir(UPLOADS_DIR) )
			mkdir(UPLOADS_DIR);
		if( !is_dir(TEMP_DIR) )
			mkdir(TEMP_DIR);
		if( !is_dir(APPLICATIONS_DIR) )
			mkdir(APPLICATIONS_DIR);
		SB_Session::start();
		SB_Request::Start();
		
	}
	public function LoadModules()
	{
		//##load modules
		$modules = SB_Module::getEnabledModules();
		$modules = array_merge($modules, $this->defaultModules);
		foreach($modules as $module)
		{
			if( file_exists(MODULES_DIR . SB_DS . $module . SB_DS . 'init.php') )
			{
				require_once MODULES_DIR . SB_DS . $module . SB_DS . 'init.php';
			}
		}
	}
	public function Start()
	{
		//##check for backend template functions.php file
		$template_dir = sb_get_template_dir('backend');
		if( file_exists($template_dir . SB_DS . 'functions.php') )
			require_once $template_dir . SB_DS . 'functions.php';
		//##check for frontend template functions.php file
		$template_dir = sb_get_template_dir('frontend');
		if( file_exists($template_dir . SB_DS . 'functions.php') )
			require_once $template_dir . SB_DS . 'functions.php';
		
		//##get current environment template and set constants
		$template_dir = sb_get_template_dir();
		
		SB_Module::do_action('init');
	}
	public function LoadLanguage()
	{
		$lang_code 	= defined('LANGUAGE') ? LANGUAGE : 'en_US';
		$domain 	= 'lt';
		$path 		= BASEPATH . SB_DS . 'locale';
		defined('LANGUAGE') or define('LANGUAGE', $lang_code);
		SB_Language::loadLanguage($lang_code, $domain, $path);
	}
	public function ProcessModule($mod)
	{
		
		if( !$mod )
			return false;
		$this->module	= $mod;
		SB_Request::setVar('mod', $mod);
		
		$dbh 			= SB_Factory::getDbh();
		$_task 			= SB_Request::getTask();
		$ctrl			= SB_Request::getString('ctrl');
		$view 			= SB_Request::getString('view', 'default');
		$module_dir		= MODULES_DIR . SB_DS . 'mod_'.$mod;
		$class_prefix 	= defined('LT_ADMIN') ? 'LT_AdminController' : 'LT_Controller';
		$file_prefix	= defined('LT_ADMIN') ? 'admin.' : '';
		if( !is_dir($module_dir) )
		{
			die('The module "'.$mod.'" does not exists.');
		}
		if( !defined('LT_ADMIN') )
		{
			sb_include('template-functions.php', 'file');
		}
		define('MODULE_DIR', $module_dir);
		define('MODULE_URL', MODULES_URL . '/mod_'.$mod);
		if( !$_task && $view )
		{
			$_task = $view;
		}
		if( strstr('.', $view) )
		{
			list(,$view) = explode('.', $view);
		}
		
		if( $_task )
		{
			SB_Module::do_action('before_process_module');
			$task = $_task;
			$controllers_dir = $module_dir . SB_DS . 'controllers';
			$controller_file = $module_dir . SB_DS . $file_prefix . 'controller.php';
			$controller_class	= $class_prefix . ucfirst(strtolower($mod));
			if( strstr($_task, '.') )
			{
				list($ctrl, $task) 	= explode('.', $_task);
				$controller_file 	= $controllers_dir . SB_DS . $file_prefix . 'controller.' . $ctrl . '.php';
				$controller_class	.= ucfirst($ctrl);   
				
			}
			if( !file_exists($controller_file) )
			{
				return false;
			}
			require_once $controller_file;
			
			$method = 'task_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $task);
			$this->controller = new $controller_class();
			if( !is_callable(array($this->controller, $method)) )
			{
				return false;
			}
			call_user_func(array($this->controller, $method));
			SB_Module::do_action('after_process_module');
		}
	}
	/**
	 * Return the current controller
	 * @return SB_Controller
	 */
	public function GetController()
	{
		return $this->controller;
	}
	public static function GetApplication($app = null)
	{
		if( !$app )
			return new SB_Application();
	
		$the_app_file = APPLICATIONS_DIR . SB_DS . 'app.' . $app . '.php';
		if( !file_exists($the_app_file) )
			throw new Exception('The application ' . ucfirst($app) . ' does not exists.');
		require_once $the_app_file;
		$the_app_class = 'SB_Application' . ucfirst($app);
		if( !class_exists($the_app_class) )
			throw new Exception('The application class "'.$the_app_class.'" does not exists');
		return new $the_app_class();
	}
}