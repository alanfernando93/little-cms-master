<?php
class SB_Request
{
	protected $vars;
	protected static $instance;
	
	protected function __construct()
	{
		
	}
	public static function Start()
	{
		self::$instance = new SB_Request();
		self::$instance->MergeServerVars();
	}
	protected function MergeServerVars()
	{
		if( $this->vars == null || empty($this->vars) )
		{
			$this->vars = array_merge($_GET, $_POST, $_REQUEST);
		}
	}
	public static function getVar($var, $default = null)
	{
		return isset(self::$instance->vars[$var]) ? self::$instance->vars[$var] : $default;
	}
	public static function setVar($var, $value)
	{
		self::$instance->vars[$var] = $value;
	}
	public static function getString($var, $default = null)
	{
		$string = trim(self::getVar($var, $default));
		return (string)$string;
		//return addslashes($string);
	}
	public static function getInt($var, $default = 0)
	{
		$integer = (int)self::getVar($var, $default);
		
		return $integer;
	}
	public static function getFloat($var, $default = 0.0)
	{
		return (float)self::getVar($var, $default);
	}
	public static function getTask($default = null)
	{
		return self::getString('task', $default);
	}
	public static function getArrayVar($array_name, $var, $default = null)
	{
		if( !($array = self::getVar($array_name)) )
			return $default;
		 return isset($array[$var]) ? $array[$var] : $default;
	}
}