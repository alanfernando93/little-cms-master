<?php
class SB_Meta
{
	public static function addMeta($table, $meta_key, $meta_value, $key_field, $key_field_id)
	{
		$date = date('Y-m-d H:i:s');
		$dbh = SB_Factory::getDbh();
		if( is_object($meta_value) || is_array($meta_value) )
			$meta_value = json_encode($meta_value);
		else
			$meta_value = trim($meta_value);//$dbh->EscapeString($meta_value);
		
		$dbh->Insert($table, array($key_field => $key_field_id, 'meta_key' => $meta_key, 'meta_value' => $meta_value, 'creation_date' => $date));
	}
	public static function getMeta($table, $meta_key, $key_field, $key_field_id, $default = null)
	{
		$dbh = SB_Factory::getDbh();
		$key_field_id = is_numeric($key_field_id) ? $key_field_id :"'$key_field_id'"; 
		$query = "SELECT meta_key, meta_value FROM $table WHERE meta_key = '$meta_key' AND $key_field = $key_field_id";
		if( !$dbh->Query($query) )
			return $default;
		
		$row = $dbh->FetchRow();
		$res = json_decode($row->meta_value);
		if( is_array($res) || is_object($res) )
			return $res;
		return $row->meta_value;
	}
	public static function updateMeta($table, $meta_key, $meta_value, $key_field, $key_field_id)
	{
		if( self::getMeta($table, $meta_key, $key_field, $key_field_id, null) === null )
		{
			self::addMeta($table, $meta_key, $meta_value, $key_field, $key_field_id);
		}
		else 
		{
			$dbh = SB_Factory::getDbh();
			if( is_object($meta_value) || is_array($meta_value) )
				$meta_value = json_encode($meta_value);
			else 
				$meta_value	= trim($meta_value);//$dbh->EscapeString($meta_value);
			
			$dbh->Update($table, array('meta_value' => $meta_value), array('meta_key' => $meta_key, $key_field => $key_field_id));
		}
	}
}