<?php
class SB_Controller
{
	protected	$document;
	protected	$view;
	
	public function __construct($doc = null)
	{
		if( $doc )
			$this->document = $doc;
		else
			$this->document = new SB_HtmlDoc(); 
	}
	public function GetDocument()
	{
		return $this->document;
	}
}