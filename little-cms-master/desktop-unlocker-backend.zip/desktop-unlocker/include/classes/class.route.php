<?php
class SB_Route
{
	public static function _($_url, $type = null)
	{
		$url = BASEURL . '/';
		if( $type === null )
		{
			if( defined('LT_ADMIN') )
				$url .= 'admin/' . $_url;
			else
			{
				$url .= $_url;
			}
		}
		elseif( $type == 'frontend' )
		{
			$url .= $_url;
		}
		elseif( $type == 'backend' )
		{
			$url .= 'admin/' . $_url;
		}
		return $url;
	}
}