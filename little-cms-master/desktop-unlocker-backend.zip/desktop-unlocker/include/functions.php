<?php
function sb_get_parameter($key, $default = '')
{
	$dbh = SB_Factory::getDbh();
	$rows = $dbh->Query("SELECT `id`, `key`, `value`, `creation_date` FROM parameters WHERE `key` = '$key'");
	
	if( $rows <= 0 )
		return $default;
	$row = $dbh->FetchRow();
	$value = json_decode($row->value);
	if( is_array($value) || is_object($value) )
		return $value;
	return $row->value;
}
function sb_update_parameter($key, $value)
{
	if( is_array($value) || is_object($value) )
	{
		$value = json_encode($value);
	}
	$dbh = SB_Factory::getDbh();
	$param = sb_get_parameter($key, null);
	if( $param === null )
	{
		$dbh->Insert('parameters', array('key' => $key, 'value' => $value, 'creation_date' => date('Y-m-d H:i:s')));
	}
	else
	{
		$dbh->Update('parameters', array('value' => $value), array('key' => $key));
	}
}
function sb_initialize_settings()
{
	$settings = sb_get_parameter('settings', array());
	foreach($settings as $key => $value)
	{
		if( is_array($value) || is_object($value) ) continue;
		define(strtoupper($key), $value);
	}
	$time_zone = defined('TIME_ZONE') ? TIME_ZONE : 'America/La_Paz';
	if( empty($time_zone) )
		$time_zone = 'America/La_Paz';
	
	date_default_timezone_set($time_zone);
}
function sb_process_module($mod = null)
{
	global $app;
	$app->ProcessModule($mod);
}
function sb_show_module()
{
	global $view_vars; 
	
	$mod 	= SB_Request::getString('mod', null);
	if( !$mod )
	{
		printf("<div class=\"no-module\">%s</div>", SB_Text::_('There is no module to process'));
		return false;
	} 
	$view 	= SB_Request::getString('view', 'default');
	$view 	= preg_replace('/[^a-zA-Z0-9\.-]/', '_', $view);
	$views_dir = MODULES_DIR . SB_DS . 'mod_' . $mod . SB_DS . 'views' . SB_DS . ( defined('LT_ADMIN') ? 'admin' : '');
	$template_views_dir = sb_get_template_dir() . SB_DS . 'modules' . SB_DS . 'mod_' . $mod . SB_DS . 'views';
	
	$view_file 				= $views_dir . SB_DS . $view . '.php';
	$template_view_file 	= $template_views_dir . SB_DS . $view . '.php';
	if( file_exists($template_view_file) )
	{
		$view_vars = isset($view_vars[$view]) ? $view_vars[$view] : array();
		extract($view_vars);
		SB_Module::do_action('before_show_view', $template_view_file, $view_vars);
		require_once SB_Module::do_action('view_template', $template_view_file);
		SB_Module::do_action('after_show_view');
	}
	else 
	{
		if( !file_exists($view_file) )
		{
			//require_once $views_dir . '/view-not-found.php';
			printf("<div class=\"view-not-found\">%s</div>", sprintf(SB_Text::_('View "%s" not found'), $view));
			return false;
		}
		$view_vars = isset($view_vars[$view]) ? $view_vars[$view] : array();
		extract($view_vars);
		SB_Module::do_action('before_show_view', $view_file, $view_vars);
		require_once SB_Module::do_action('view_template', $view_file);
		SB_Module::do_action('after_show_view');
	}
	
	
}
/**
 * Get template directory
 * 
 * @param string frontend|backend|null
 * If null is passed it will returns automatically the template directory of current environment 
 * @return NULL|string
 */
function sb_get_template_dir($type = null)
{
	static $template_dir = null;
	if( $type != null )
	{
		$template = ($type == 'backend') ? sb_get_parameter('template_admin', 'default') : sb_get_parameter('template_frontend', 'default');
		$templates_dir 	= ($type == 'backend') ? ADM_TEMPLATES_DIR : TEMPLATES_DIR;
		return $templates_dir . SB_DS . $template;
	}
	if( $template_dir != null )
		return $template_dir;
	
	$template 		= defined('LT_ADMIN') ? sb_get_parameter('template_admin', 'default') : sb_get_parameter('template_frontend', 'default');
	$templates_dir 	= defined('LT_ADMIN') ? ADM_TEMPLATES_DIR : TEMPLATES_DIR;
	defined('TEMPLATE_DIR') or define('TEMPLATE_DIR', $template_dir);
	return $templates_dir . SB_DS . $template;
}
function sb_get_template_url()
{
	static $template_url = null;
	if( $template_url != null )
		return $template_url;
	
	$template		= defined('LT_ADMIN') ? sb_get_parameter('template_admin', 'default') : sb_get_parameter('template_frontend', 'default');
	$template_url	= defined('LT_ADMIN') ? ADMIN_URL . '/templates/' . $template :  TEMPLATES_URL . '/' . $template;
	defined('TEMPLATE_URL') or define('TEMPLATE_URL', $template_url);
	
	return $template_url;
}
function sb_process_template($tpl_file = 'index.php')
{
	global $template_html, $view_vars;
	
	SB_Module::do_action('before_process_template');
	$template_dir 	= sb_get_template_dir();//defined('LT_ADMIN') ? ADM_TEMPLATES_DIR : TEMPLATES_DIR;
	$template_url	= sb_get_template_url();
	$mod			= SB_Request::getString('mod', null);
	
	if( defined('LT_ADMIN') )
	{
		sb_build_admin_menu();
	}
	else 
	{
			
	}
	
	
	if( !$mod )
	{
		$mod = defined('LT_ADMIN') ? 'dashboard' : 'content';
	}
	$view 			= SB_Request::getString('view', 'default');
	
	extract(isset($view_vars[$view]) ? $view_vars[$view] : array());
	ob_start();
	require_once $template_dir. SB_DS . $tpl_file;
	$template_html = ob_get_clean();
}
function sb_show_template()
{
	global $template_html;
	
	print $template_html;
	sb_end();
}
function sb_set_view($view)
{
	SB_Request::setVar('view', $view);
}
function sb_end()
{
	$dbh = SB_Factory::getDbh();
	$dbh->Close();
	SB_Module::do_action('end');
}
function sb_is_user_logged_in()
{
	$session_var = '';
	$cookie_name = '';
	$timeout_var = '';
	if( defined('LT_ADMIN') )
	{
		$session_var = 'admin_user';
		$cookie_name = 'lt_session_admin';
		$timeout_var = 'admin_timeout';
	}
	else 
	{
		$session_var = 'user';
		$cookie_name = 'lt_session';
		$timeout_var = 'timeout';
	}
	$user 		=& SB_Session::getVar($session_var);
	$session 	=& SB_Session::getVar($cookie_name);
	$timeout	=& SB_Session::getVar($timeout_var);
	
	if( !$user || !$session || !$timeout )
	{
		return false;
	}
	//##check session expiration
	$time_diff = time() - $timeout;
	if( $time_diff > SESSION_EXPIRE )
	{
		SB_MessagesStack::AddMessage(SB_Text::_('La session ha expirado', 'info'), 'info');
		$ctrl = SB_Module::GetControllerInstance('users');
		$ctrl->task_logout();
		return false;
	}
	//##renew the timeout
	$timeout = time();
	return true;
}
function sb_set_view_var($name, $value, $view = null)
{
	global $view_vars; //##declare global variable
	
	if( $view_vars == null || !is_array($view_vars) )
		$view_vars = array();
	$view = $view ? $view : SB_Request::getString('view', 'default');
	if( !isset($view_vars[$view]) )
	{
		$view_vars[$view] = array();
	}
	$view_vars[$view][$name] = $value;
}
function sb_include_module_helper($module)
{
	$module_path = MODULES_DIR . SB_DS . 'mod_' . $module;
	$helper_file = 'helper.' . $module . '.php';
	if( !file_exists($module_path . SB_DS . $helper_file) )
		return false;
	require_once $module_path . SB_DS . $helper_file;
	return true;
}
function sb_download_image($url)
{
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
	$res = curl_exec($ch);
	curl_close($ch);
	return $res;
}
function sb_get_content_images($content)
{
	/*
	preg_match_all('/<img.*src="([^"].*.[jpg|png|gif])["]{1}[\s+|.*].*>/i', $content, $matches);
	print_r($matches);die();
	if( count($matches[1]) )
	{
		return $matches[1];
	}
	*/
	$dom = new DOMDocument();
	$dom->loadHTML($content);
	$items = $dom->getElementsByTagName('img');
	$images = array();
	foreach($items as $item)
	{
		$images[] = $item->getAttribute('src');
	}
	return $images;
}
function sb_get_youtube_img($url)
{
	//$r = urldominian($url);
	//var_dump($r);
	$ext = explode(".", $url);
	$HTMLVER = '';
	//if($r == 'www.youtube.com')
	if( stristr($url, 'youtube.com') )
	{
		preg_match("#v=([a-zA-Z0-9-_]{10,13})#", $url, $dat);
		$HTMLVER = '-_-'.$dat[1].'.jpg';
	}
	else if(end($ext) === 'jpg' || end($ext) === 'gif' || end($ext) === 'png' )
	{
		$HTMLVER = $url;
	}
	else 
	{
		$HTMLVER = NULL;
	}
	return $HTMLVER;
}
function urldominian($text) {
	preg_match('@^(?:http://)?([^/]+)@i',$text, $coincidencias);
	return $coincidencias[1];
}
function sb_captcha($file = null, $session_var = 'login_captcha')
{
	// Create a blank image and add some text
	$im 		= imagecreatetruecolor(120, 40);
	$text_color = imagecolorallocate($im, 233, 14, 91);
	$val		= rand(9,true).rand(9,true).rand(9,true).rand(9,true).rand(9,true).rand(9,true);
	SB_Session::setVar($session_var, $val);
	imagestring($im, 5, 5, 5,  $val , $text_color);
	// Save the image as 'simpletext.jpg'
	header('Content-type: image/jpeg');
	imagejpeg($im, null, 100);
	// Free up memory
	imagedestroy($im);
}
function sb_permission_exists($perm)
{
	$dbh = SB_Factory::getDbh();
	$query = "SELECT permission_id FROM permissions WHERE permission = '$perm' LIMIT 1";
	if( !$dbh->Query($query) )
		return null;
	return $dbh->FetchRow();
}
function sb_get_permissions($labels = true)
{
	$dbh = SB_Factory::getDbh();
	$query = "SELECT * FROM permissions";
	$dbh->Query($query);
	if( $labels )
		return $dbh->FetchResults();
	$perms = array();
	foreach($dbh->FetchResults() as $p)
	{
		$perms[] = $p->permission;
	}
	return $perms;
}
function sb_redirect($link)
{
	header('Location: ' . $link);
	die();
}
function sb_add_script($src, $id, $order = 0)
{
	$scripts = &SB_Globals::GetVar('scripts');
	if( !$scripts )
	{
		SB_Globals::SetVar('scripts', array());
		$scripts =& SB_Globals::GetVar('scripts');
	}
	$scripts[] = array('id' => $id, 'src' => $src);
}

function sb_include($file, $type = 'class')
{
	if( $type == 'class' && file_exists(INCLUDE_DIR . SB_DS . 'classes' . SB_DS . $file) )
	{
		return require_once INCLUDE_DIR . SB_DS . 'classes' . SB_DS . $file;
	}
	if( $type = 'file' && file_exists(INCLUDE_DIR . SB_DS . $file) )
	{
		return require_once INCLUDE_DIR . SB_DS . $file;
	}
	if( $type == null && file_exists($file) )
	{
		return require_once $file;
	}
}
function sb_include_lib($lib_file)
{
	$lib_path = INCLUDE_DIR . SB_DS . 'libs' . SB_DS . $lib_file;
	sb_include($lib_path, null);
}
/**
 * Get unique filename and return the full path filename
 * @param string $filename
 * @param string $directory
 * @return string The unique full path filename
 */
function sb_get_unique_filename($filename, $directory)
{
	$pathinfo = pathinfo($filename);
	$base = $pathinfo['filename'];
	$ext = isset($pathinfo['extension']) ? $pathinfo['extension'] : '';
	$ext = $ext == '' ? $ext : '.' . $ext;
	$unique = $base;
	$suffix = 0;
	// Get unique file name for the file, by appending random suffix.
	while( file_exists($directory . SB_DS . $unique . $ext) )
	{
		$suffix += rand(1, 999);
		$unique = $base.'-'.$suffix;
	}
	$result =  $directory . SB_DS . $unique . $ext;
	//Create an empty target file
	if ( !touch($result) )
	{
		//Failed
		$result = false;
	}
	return $result;
}
function sb_get_module_url($mod)
{
	return MODULES_URL . '/mod_'.$mod;
}
function sb_format_date($date, $format = null)
{
	$date_format = 'Y-m-d';
	if( defined('DATE_FORMAT') )
	{
		$date_format = DATE_FORMAT;
	}
	if( $format )
	{
		$date_format = $format;
	}
	$date = is_numeric($date) ? $date : strtotime($date);

	return date("$date_format", $date);
}
function sb_format_time($time)
{
	$time_format = 'H:i:s';
	if( defined('DATE_FORMAT') )
	{
		$date_format = DATE_FORMAT;
	}
	if( defined('TIME_FORMAT') )
	{
		$time_format = TIME_FORMAT;
	}
	$date_time = strtotime($date);

	return date("$date_format $time_format", $date_time);
}
function sb_format_datetime($date, $format = null)
{
	$date_format = 'Y-m-d';
	$time_format = 'H:i:s';
	if( defined('DATE_FORMAT') )
	{
		$date_format = DATE_FORMAT;
	}
	if( defined('TIME_FORMAT') )
	{
		$time_format = TIME_FORMAT;
	}
	$the_format = "$date_format $time_format";
	if( $format != null )
	{
		$the_format = $format;  
	}
	$date_time = is_numeric($date) ? $date : strtotime($date);
	
	return date($the_format, $date_time);
}
/**
 * Get browser name
 * 
 * @return string
 */
function sb_get_browser()
{
	$ExactBrowserNameUA=$_SERVER['HTTP_USER_AGENT'];

	if (strpos(strtolower($ExactBrowserNameUA), "safari/") and strpos(strtolower($ExactBrowserNameUA), "opr/")) {
		// OPERA
		$ExactBrowserNameBR="Opera";
	} elseIf (strpos(strtolower($ExactBrowserNameUA), "safari/") and strpos(strtolower($ExactBrowserNameUA), "chrome/")) {
		// CHROME
		$ExactBrowserNameBR="Chrome";
	} elseIf (strpos(strtolower($ExactBrowserNameUA), "msie")) {
		// INTERNET EXPLORER
		$ExactBrowserNameBR="Internet Explorer";
	} elseIf (strpos(strtolower($ExactBrowserNameUA), "firefox/")) {
		// FIREFOX
		$ExactBrowserNameBR="Firefox";
	} elseIf (strpos(strtolower($ExactBrowserNameUA), "safari/") and strpos(strtolower($ExactBrowserNameUA), "opr/")==false and strpos(strtolower($ExactBrowserNameUA), "chrome/")==false) {
		// SAFARI
		$ExactBrowserNameBR="Safari";
	} else {
		// OUT OF DATA
		$ExactBrowserNameBR="OUT OF DATA";
	};

	return $ExactBrowserNameBR;
}
/**
 * Gives a nicely-formatted list of timezone strings.
 *
 *
 * @param string $selected_zone Selected timezone.
 * @return string
 */
function sb_timezone_choice( $selected_zone ) 
{
	static $mo_loaded = false;

	$continents = array( 'Africa', 'America', 'Antarctica', 'Arctic', 'Asia', 'Atlantic', 'Australia', 'Europe', 'Indian', 'Pacific');

	$zonen = array();
	foreach ( timezone_identifiers_list() as $zone ) 
	{
		$zone = explode( '/', $zone );
		if ( !in_array( $zone[0], $continents ) ) 
		{
			continue;
		}

		// This determines what gets set and translated - we don't translate Etc/* strings here, they are done later
		$exists = array(
				0 => ( isset( $zone[0] ) && $zone[0] ),
				1 => ( isset( $zone[1] ) && $zone[1] ),
				2 => ( isset( $zone[2] ) && $zone[2] ),
		);
		$exists[3] = ( $exists[0] && 'Etc' !== $zone[0] );
		$exists[4] = ( $exists[1] && $exists[3] );
		$exists[5] = ( $exists[2] && $exists[3] );

		$zonen[] = array(
				'continent'   => ( $exists[0] ? $zone[0] : '' ),
				'city'        => ( $exists[1] ? $zone[1] : '' ),
				'subcity'     => ( $exists[2] ? $zone[2] : '' ),
				't_continent' => ( $exists[3] ? str_replace( '_', ' ', $zone[0] ) : '' ),
				't_city'      => ( $exists[4] ? str_replace( '_', ' ', $zone[1] ) : '' ),
				't_subcity'   => ( $exists[5] ? str_replace( '_', ' ', $zone[2] ) : '' )
		);
	}
	//usort( $zonen, '_wp_timezone_choice_usort_callback' );

	$structure = array();

	if ( empty( $selected_zone ) ) {
		$structure[] = '<option selected="selected" value="">' . SB_Text::_('-- ciudad --') . '</option>';
	}

	foreach ( $zonen as $key => $zone ) {
		// Build value in an array to join later
		$value = array( $zone['continent'] );

		if ( empty( $zone['city'] ) ) {
			// It's at the continent level (generally won't happen)
			$display = $zone['t_continent'];
		} else {
			// It's inside a continent group

			// Continent optgroup
			if ( !isset( $zonen[$key - 1] ) || $zonen[$key - 1]['continent'] !== $zone['continent'] ) {
				$label = $zone['t_continent'];
				$structure[] = '<optgroup label="'. $label .'">';
			}

			// Add the city to the value
			$value[] = $zone['city'];

			$display = $zone['t_city'];
			if ( !empty( $zone['subcity'] ) ) {
				// Add the subcity to the value
				$value[] = $zone['subcity'];
				$display .= ' - ' . $zone['t_subcity'];
			}
		}

		// Build the value
		$value = join( '/', $value );
		$selected = '';
		if ( $value === $selected_zone ) {
			$selected = 'selected="selected" ';
		}
		$structure[] = '<option ' . $selected . 'value="' .  $value . '">' . $display . "</option>";

		// Close continent optgroup
		if ( !empty( $zone['city'] ) && ( !isset($zonen[$key + 1]) || (isset( $zonen[$key + 1] ) && $zonen[$key + 1]['continent'] !== $zone['continent']) ) ) {
			$structure[] = '</optgroup>';
		}
	}

	// Do UTC
	$structure[] = '<optgroup label="UTC">';
	$selected = '';
	if ( 'UTC' === $selected_zone )
		$selected = 'selected="selected" ';
	$structure[] = '<option ' . $selected . 'value="UTC">UTC</option>';
	$structure[] = '</optgroup>';

	// Do manual UTC offsets
	$structure[] = '<optgroup label="Manual Offsets">';
	$offset_range = array (-12, -11.5, -11, -10.5, -10, -9.5, -9, -8.5, -8, -7.5, -7, -6.5, -6, -5.5, -5, -4.5, -4, -3.5, -3, -2.5, -2, -1.5, -1, -0.5,
			0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 5.75, 6, 6.5, 7, 7.5, 8, 8.5, 8.75, 9, 9.5, 10, 10.5, 11, 11.5, 12, 12.75, 13, 13.75, 14);
	foreach ( $offset_range as $offset ) {
		if ( 0 <= $offset )
			$offset_name = '+' . $offset;
		else
			$offset_name = (string) $offset;

		$offset_value = $offset_name;
		$offset_name = str_replace(array('.25','.5','.75'), array(':15',':30',':45'), $offset_name);
		$offset_name = 'UTC' . $offset_name;
		$offset_value = 'UTC' . $offset_value;
		$selected = '';
		if ( $offset_value === $selected_zone )
			$selected = 'selected="selected" ';
		$structure[] = '<option ' . $selected . 'value="' . $offset_value . '">' . $offset_name . "</option>";

	}
	$structure[] = '</optgroup>';

	return join( "\n", $structure );
}