<?php
abstract class SB_Database
{
	public $db_type;
	public $lastId;
	public $lastQuery;
	protected	$lcw = '';
	protected	$rcw = '';
	abstract public function Close();
	abstract public function Query($query);
	abstract public function FetchResults();
	abstract public function FetchRow();
	abstract public function NumRows();
	abstract public function EscapeString($str);
	public function Insert($table, array $data)
	{
		$columns = array_keys($data);
		$vals = array_values($data);
		$columns = array_map(create_function('$col', 'return "'.$this->lcw.'$col'.$this->rcw.'";'), $columns);
		//print_r($vals);die();
		$query = "INSERT INTO $table (".implode(',', $columns).") VALUES(";
		foreach($vals as $index => $v)
		{
			$_v = $this->EscapeString($v);
			if(is_numeric($_v))
				$query .= "$_v,";
			elseif( is_string($_v))
				$query .= "'$_v',";
		}
		$query = substr($query, 0, -1) . ");";
		$this->Query($query);
		
		return $this->lastId;
	}
	public function Update($table, array $data, array $where)
	{
		$query = "UPDATE $table SET ";
		foreach($data as $col => $val)
		{
			$_val = $this->EscapeString($val);
			/*
			if( is_numeric($_val) )
				$query .= "$col = $_val,";
			elseif( is_string($_val) )
			*/
			$query .= "{$this->lcw}$col{$this->rcw} = '$_val',";
		}
		$query = substr($query, 0, -1);
		$query .= " WHERE ";
		foreach($where as $col => $val)
		{
			$_val = $this->EscapeString($val);
			//if( is_numeric($_val) )
				//$query .= "$col = $_val AND ";
			//elseif( is_string($_val) )
			$query .= "{$this->lcw}$col{$this->rcw} = '$_val' AND ";
		}
		$query = substr($query, 0, -4);
		//print $query;die();
		$this->Query($query);
	}
	public function Delete($table, array $where)
	{
		$cols = array_keys($where);
		$vals = array_values($where);
		$query = "DELETE FROM $table WHERE ";
		foreach($where as $col => $val)
		{
			$_val = $this->EscapeString($val);
			if( is_numeric($_val) )
				$query .= "{$this->lcw}$col{$this->rcw} = $_val AND ";
			else
				$query .= "{$this->lcw}$col{$this->rcw} = '$_val' AND ";
		}
		$query = substr($query, 0, -4);
		return $this->Query($query);
	}
}