<?php
class SB_MySQL extends SB_Database 
{
	protected 	$link = false;
	protected	$dbh;
	protected 	$errorCode;
	protected 	$error;
	protected 	$result;
	
	public function __construct($server, $username, $password, $database = null)
	{
		$this->db_type = 'mysql';
		//$this->link = mysql_pconnect($server, $username, $password);
		//$this->link = mysql_connect($server, $username, $password);
		$this->dbh	= new mysqli($server, $username, $password, $database);
		if( !$this->dbh )
		{
			throw new Exception("Fatal error: cannot connect to database server");
		}
		// No afectará a $mysqli->real_escape_string();
		$this->dbh->query("SET NAMES utf8");
		
		// No afectará a $mysqli->real_escape_string();
		$this->dbh->query("SET CHARACTER SET utf8");
		
		// Pero esto sí afectará a $mysqli->real_escape_string();
		$this->dbh->set_charset('UTF8');
		$this->lcw = '`';
		$this->rcw = '`';
	}
	public function selectDB($database)
	{
		//$res = mysql_select_db($database, $this->link);
		$res = $this->dbh->select_db($database);
		if($res == false)
		{
			throw new Exception("Fatal error: cannot connect to database '$database' or database 
								does not exists.");
		}
	}
	public function getErrorCode()
	{
		return $this->errorCode;
	}
	public function Query($query)
	{
		$query = trim($query);
		//$this->result = mysql_query($query, $this->link);
		$this->result	= $this->dbh->query($query);
		if( !$this->result )
		{
			if( defined("DEVELOPMENT") && DEVELOPMENT == 1 )
				error_log("MySQL Error: ".mysql_error()."\n Error code: ".mysql_errno()." Query: $query\n",3,LOG_FILE);
			$this->errorCode = $this->dbh->errno;
			$this->error = $this->dbh->error;
			throw new Exception( 'Error['.$this->errorCode.']: '. $this->error . ' Your query was: ' .$query );
			
		}
		$pattern = '/^[update|delete]/isU';
		$res = preg_match($pattern, $query, $matches);
		if( $res > 0)
			return $this->dbh->affected_rows;
			
		$res = preg_match('/^insert/isU', $query, $matches);
		if( $res > 0 )
		{
			$this->lastId = $this->dbh->insert_id; 
			return $this->lastId;
		}
			
		$res = preg_match('/^select/isU', $query, $matches);
		if( $res > 0 )
			return $this->result->num_rows;
			
		return $this->result;
	}
	public function Close()
	{
		$this->dbh->close();
	}
	public function FetchArray()
	{
		return $this->result->fetch_array(MYSQL_ASSOC);
		//return mysql_fetch_array($this->result, MYSQL_ASSOC);
	}
	public function FetchRow()
	{
		return $this->result->fetch_object();
	}
	public function GetVar($varname)
	{
		$row = $this->FetchArray();
		
		if( isset($row[$varname]) )
		{
			return $row[$varname];
		}
		return null;
	}
	public function NumRows()
	{
		return $this->result->num_rows;
	}
	public function getVarFromQuery($query, $varname)
	{
		$this->Query($query);
		
		return $this->GetVar($varname);
	}
	public function FetchObject($class = null)
	{
		if($class == null)
			return mysql_fetch_object($this->result);
		else
			return mysql_fetch_object($this->result, $class);
	}
	public function FetchResults()
	{
		$results = array();
		while( $row = $this->result->fetch_object() )
		{
			$results[] = $row;
		}
		return $results;
	}
	
	public function fetch_all_into_array_from_query($query)
	{
		return $this->fetch_all_into_array($this->query($query));
	}
	public function fetch_object_from_query($query)
	{
		$this->query($query);
		return mysql_fetch_object($this->result);
	}
	
	public function fetch_all_into_object()
	{
		$results = array();
		while($row = $this->FetchObject() )
		{
			$results[] = $row;
		}
		return $results;
	}
	
	public function fetch_all_into_object_from_query($query)
	{
		return $this->fetch_all_into_object($this->query($query));
	}
	public function EscapeString($string)
	{
		return $this->dbh->real_escape_string($string);
	}
	public function escapeArray(array $array)
	{
		if(is_array($array))
		{
			$escapedArray = array();
			foreach($array as $index => $value)
			{
				$escapedArray[$index] = $this->escapeString($value);
			}
			return $escapedArray;
		}
	}
	public function AffectedRows($in_ResulSet)
	{
		return mysql_affected_rows();
	}
	public function getNextId($table, $columnId)
	{
		$query = "SELECT MAX($columnId) id FROM $table";
		$res = $this->Query($query);
		$rows = $this->NumRows($res);
		if($rows <= 0 )
		{
			return 1;
		}
		$row = $this->FetchArray($res);
		return  $row["id"] + 1;
	}
	public function beginTransaction()
	{
		$this->Query("BEGIN");
	}
	public function commit()
	{
		$this->Query("COMMIT");
	}
	public function rollBack()
	{
		$this->Query("ROLLBACK");
	}
	public function getConnection()
	{
		return $this->link;
	}
	public function setResource($res)
	{
		$this->result = $res;
	}
	public function getResource()
	{
		return $this->result;
	}
}

?>