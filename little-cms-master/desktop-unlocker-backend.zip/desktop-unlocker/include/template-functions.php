<?php
function lt_title()
{
	global $app;
	
	//var_dump($app);
	print $app->GetController()->GetDocument()->GetTitle();
}
function lt_site_title()
{
	return defined('SITE_TITLE') ? SITE_TITLE : '';
}
function lt_get_template($tpl_file)
{
	$theme_dir = sb_get_template_dir();
	if( !file_exists($theme_dir . SB_DS . $tpl_file) )
		return null;
	return $theme_dir . SB_DS . $tpl_file;
}
function lt_include_template($tpl_file)
{
	$tpl_file = $tpl_file . '.php';
	if( $tpl = lt_get_template($tpl_file) )
	{
		include $tpl;
	}
}
function lt_get_header($tpl = null)
{
	$theme_dir = sb_get_template_dir();
	$tpl_file = 'header' . ($tpl ? '-'.$tpl : '') . '.php';
	
	include $theme_dir . SB_DS . $tpl_file;
}
function lt_get_footer($tpl = null)
{
	$theme_dir = sb_get_template_dir();
	$tpl_file = 'footer' . ($tpl ? '-'.$tpl : '') . '.php';

	include $theme_dir . SB_DS . $tpl_file;
}
function lt_get_sidebar($tpl = null)
{
	$theme_dir = sb_get_template_dir();
	$tpl_file = 'sidebar' . ($tpl ? '-'.$tpl : '') . '.php';

	include $theme_dir . SB_DS . $tpl_file;
}
function lt_pagination($base_link, $total_pages, $current_page)
{
	if( $total_pages <= 1 )
		return false;
	//var_dump($base_link);
	list($base_link, $query_string) = explode('?', $base_link);
	$vars = array();
	if( !empty($query_string) )
	{
		parse_str($query_string, $vars);
		$vars['page'] = $current_page - 1;
	}
	
	
	?>
	<nav id="pagination">
		<ul class="pagination">
			<?php if($current_page > 1): ?>
			<li>
		    	<a href="<?php printf("%s?%s", $base_link, http_build_query($vars)); ?>" aria-label="Previous">
		    		<span aria-hidden="true">&laquo;</span>
		    	</a>
		    </li>
			<?php endif; ?>
			<?php $_vars = $vars;?>
			<?php for($i = 1; $i <= $total_pages; $i++): $_vars['page'] = $i; ?>
			<li <?php print ($current_page == $i) ? 'class="active"' : ''; ?>>
				<a href="<?php printf("%s?%s", $base_link, http_build_query($_vars)); ?>">
					<?php print $i; ?>
				</a>
			</li>
			<?php endfor;?>
			<?php if( $current_page < $total_pages ): $_vars = $vars; $_vars['page'] = $current_page + 1; ?>
			<li>
		    	<a href="<?php printf("%s?%s", $base_link, http_build_query($_vars)); ?>" aria-label="Next">
		    		<span aria-hidden="true">&raquo;</span>
		    	</a>
		    </li>
			<?php endif; ?>
		</ul>
	</nav>
	<?php 
}
function lt_parse_shortcodes($string)
{
	return SB_Shortcode::ParseShortcodes($string);
}
function lt_scripts()
{
	$scripts =& SB_Globals::GetVar('scripts');
	if( !$scripts || !is_array($scripts) ) return;

	foreach($scripts as $js)
	{
		printf("<script id=\"%s\" type=\"text/javascript\" src=\"%s\"></script>\n", $js['id'], $js['src']);
	}
	SB_Module::do_action('scripts');
}
function lt_header()
{
	SB_Module::do_action('lt_header');
}
function lt_footer()
{
	SB_Module::do_action('lt_footer');
}