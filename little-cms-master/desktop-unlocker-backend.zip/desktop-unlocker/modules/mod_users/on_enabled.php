<?php
$dbh = SB_Factory::getDbh();
SB_Module::RunSQL('users');
$permissions = array(
		array('permission' => 'manage_settings', 'label'	=> SB_Text::_('Gestionar configuracion', 'users')),
		array('permission' => 'manage_general_settings', 'label'	=> SB_Text::_('Configuraci&oacute;n General', 'users')),
		array('permission' => 'manage_design_settings', 'label'	=> SB_Text::_('Configuraci&oacute;n de Est&eacute;tica', 'users')),
		array('permission' => 'manage_limit_settings', 'label'	=> SB_Text::_('Configuraci&oacute;n de Aplicaci&oacute;n', 'users')),
		array('permission' => 'manage_roles', 'label'	=> SB_Text::_('Gestionar roles', 'users')),
		array('permission' => 'create_role', 'label'	=> SB_Text::_('Crear rol', 'users')),
		array('permission' => 'edit_role', 'label'		=> SB_Text::_('Editar rol', 'users')),
		array('permission' => 'delete_role', 'label'	=> SB_Text::_('Borrar rol', 'users')),
		array('permission' => 'manage_users', 'label'	=> SB_Text::_('Gestionar usuarios', 'users')),
		array('permission' => 'create_user', 'label'	=> SB_Text::_('Crear usuario', 'users')),
		array('permission' => 'edit_user', 'label'		=> SB_Text::_('Editar usuario', 'users')),
		array('permission' => 'delete_user', 'label'	=> SB_Text::_('Borrar usuario', 'users')),
);
$local_permissions = sb_get_permissions(false);
foreach($permissions as $perm)
{
	if( in_array($perm['permission'], $local_permissions) ) continue;
	$dbh->Insert('permissions', $perm);
}