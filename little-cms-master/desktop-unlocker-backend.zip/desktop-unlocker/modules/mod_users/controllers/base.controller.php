<?php
abstract class LT_ControllerUsersBase extends SB_Controller
{
	public function task_upload_image()
	{
		require_once INCLUDE_DIR . SB_DS . 'qqFileUploader.php';
		$uh = new qqFileUploader();
		$uh->allowedExtensions = array('jpg', 'jpeg', 'gif', 'png', 'bmp');
		// Specify max file size in bytes.
		//$uh->sizeLimit = 10 * 1024 * 1024; //10MB
		// Specify the input name set in the javascript.
		$uh->inputName = 'qqfile';
		// If you want to use resume feature for uploader, specify the folder to save parts.
		$uh->chunksFolder = 'chunks';
		$res = $uh->handleUpload(TEMP_DIR);
		$file_path = TEMP_DIR . SB_DS . $uh->getUploadName();
		sb_include('class.image.php');
		$img = new SB_Image($file_path);
		//if( $img->getWidth() > 150 || $img->getHeight() > 150)
		{
			$img->resizeImage(150, 150);
			$img->save($file_path);
		}
		$res['uploadName'] = $uh->getUploadName();
		$res['image_url'] = BASEURL . '/temp/' . $res['uploadName'];
		if( $user_id = SB_Request::getInt('user_id') )
		{
			//sb_update_user_meta($user_id, '', $meta_value);
		}
		if( sb_is_user_logged_in() && SB_Request::getInt('update') )
		{
			$user_id = sb_get_current_user()->user_id;
			$image_file	= $res['uploadName'];
			$user_dir	= UPLOADS_DIR . SB_DS . sb_build_slug(sb_get_current_user()->email);
			if( $old_image = sb_get_user_meta($user_id, '_image') )
			{
				file_exists($user_dir . SB_DS . $old_image) && @unlink($user_dir . SB_DS . $old_image);
			}
			
			@rename(TEMP_DIR . SB_DS . $image_file, $user_dir . SB_DS . $image_file);
			sb_update_user_meta($user_id, '_image', $image_file);
			$res['image_url'] = UPLOADS_URL . '/' . basename($user_dir) . '/' . $res['uploadName'];
			$res['user_dir']	= $user_dir; 
		}
		die(json_encode($res));
	}
}