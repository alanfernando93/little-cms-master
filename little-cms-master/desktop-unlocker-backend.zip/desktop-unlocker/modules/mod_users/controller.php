<?php
require_once MOD_USERS_DIR . SB_DS . 'controllers' . SB_DS . 'base.controller.php';
class LT_ControllerUsers extends LT_ControllerUsersBase
{
	public function task_do_login()
	{
		$username 	= SB_Request::getString('username');
		$pwd		= SB_Request::getString('pwd');
		$captcha	= SB_Request::getString('captcha');
		$dbh 		= SB_Factory::getDbh();
		$query 		= sprintf("SELECT * FROM users WHERE username = '%s' LIMIT 1", $username);
		$rows 		= $dbh->Query($query);
		if( $rows <= 0 )
		{
			SB_Module::do_action('authenticate_error', null, $username, $pwd);
			SB_MessagesStack::AddMessage('Usuario o contrase&ntilde;a invalida', 'error');
			sb_redirect(SB_Route::_('index.php?mod=users'));
		}
		$row = $dbh->FetchRow();
		
		if( $row->pwd != md5($pwd) )
		{
			SB_Module::do_action('authenticate_error', $row, $username, $pwd);
			SB_MessagesStack::AddMessage('Usuario o contrase&ntilde;a invalida', 'error');
			sb_redirect(SB_Route::_('index.php?mod=users'));
		}
		$form_captcha = SB_Session::getVar('login_captcha');
		if( $captcha != $form_captcha )
		{
			SB_Module::do_action('authenticate_error', $row, $username, $pwd);
			SB_MessagesStack::AddMessage(SB_Text::_('El texto de seguridad es invalido'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=users'));
		}
		SB_Session::setVar('user', $row);
		$cookie_value = md5(serialize($row) . ':' . session_id());
		SB_Session::setVar('lt_session', $cookie_value);
		SB_Session::setVar('timeout', time());
		SB_Session::unsetVar('login_captcha');
		//##mark user as logged in
		sb_update_user_meta($row->user_id, '_logged_in', 'yes');
		sb_update_user_meta($row->user_id, '_logged_in_time', time());
		SB_Module::do_action('authenticated', $row, $username, $pwd);
		sb_redirect(SB_Route::_('index.php?mod=users'));
	}
	public function task_logout()
	{
		/*
		if( !sb_is_user_logged_in() )
		{
			sb_redirect(SB_Route::_('index.php'));
		}
		*/
		$user = sb_get_current_user();
		if( $user->user_id )
		{
			sb_update_user_meta($user->user_id, '_logged_in', 'no');
			sb_update_user_meta($user->user_id, '_logged_in_time', 0);
		}
		SB_Module::do_action('logout', $user);
		SB_Session::unsetVar('user');
		SB_Session::unsetVar('lt_session');
		SB_Session::unsetVar('timeout');
		sb_redirect(SB_Route::_('index.php'));
	}
	public function task_default()
	{
		if( !sb_is_user_logged_in() )
		{
			sb_set_view('form-login');
			return false;
		}
		$user = sb_get_current_user();
		$image = sb_get_user_meta($user->user_id, '_image');
		$image_url = '';
		if( !$image )
		{
			$image_url = MODULE_URL . '/images/nobody.png';
		}
		else
		{
			$image_url = UPLOADS_URL . '/' . sb_build_slug($user->username) . '/' . $image;
		}
		
		$user = new SB_User($user->user_id);
		sb_set_view_var('user', $user);
		sb_set_view_var('image_url', $image_url);
	}
	public function task_profile()
	{
		sb_add_script(BASEURL . '/js/fineuploader/all.fine-uploader.min.js', 'fineuploader');
		sb_add_script(MOD_USERS_URL . '/js/frontend.js', 'user-frontend-js');
		sb_set_view_var('upload_endpoint', SB_Route::_('index.php?mod=users&task=upload_image&update=1'));
		$this->task_default();
	}
	public function task_save_profile()
	{
		if( !sb_is_user_logged_in() )
		{
			sb_redirect(SB_Route::_('index.php?mod=users'));
		}
		$user_id 		= SB_Request::getInt('user_id');
		$role_id 		= SB_Request::getInt('role_id');
		$first_name		= SB_Request::getString('first_name');
		$last_name 		= SB_Request::getString('last_name');
		//$email			= SB_Request::getString('email');
		$pwd			= SB_Request::getString('pwd');
		$notes			= SB_Request::getString('notes');
		$observations	= SB_Request::getString('observations');
		$image_file		= SB_Request::getString('imagefile');
		
		if( empty($first_name) )
		{
			SB_MessagesStack::AddMessage('Debe ingresar los nombres.', 'error');
			$this->task_default();
			return false;
		}
		if( empty($last_name) )
		{
			SB_MessagesStack::AddMessage('Debe ingresar los apellidos.', 'error');
			$this->task_default();
			return false;
		}
		/*
		if( empty($email) )
		{
			SB_MessagesStack::AddMessage('Debe ingresar el email.', 'error');
			return false;
		}
		*/
		$user 		= new SB_User(sb_get_current_user()->user_id);
		$user_id	= $user->user_id;
		$user_dir	= UPLOADS_DIR . SB_DS . sb_build_slug($user->email);
		$dbh = SB_Factory::getDbh();
		/*
		$query = "SELECT user_id FROM users WHERE username = '$email' LIMIT 1";
		if( !$user_id && $dbh->Query($query) )
		{
			SB_MessagesStack::AddMessage('El nombre de usuario ya existe, elija uno diferente.', 'error');
			return false;
		}
		*/
		$cdate = date('Y-m-d H:i:s');
		$data = array(
				'first_name'				=> $dbh->EscapeString($first_name),
				'last_name'					=> $dbh->EscapeString($last_name),
				//'email'						=> $dbh->EscapeString($email),
				//'username'					=> $dbh->EscapeString($email),
				//'pwd'						=> md5($pwd),
				//'role_id'					=> $role_id,
				//'status'					=> 'enabled',
				'last_modification_date'	=> $cdate
		);
		if( !is_dir($user_dir) )
			mkdir($user_dir);
		/*
		if( file_exists(TEMP_DIR . SB_DS . $image_file) )
		{
			rename(TEMP_DIR . SB_DS . $image_file, $user_dir . SB_DS . $image_file);
		}
		*/
		if( !empty($pwd) )
		{
			$data['pwd'] = md5($pwd);
		}
		$dbh->Update('users', $data, array('user_id' => $user->user_id));
		/*
		sb_update_user_meta($user_id, '_observations', $observations);
		sb_update_user_meta($user_id, '_notes', $notes);
		sb_update_user_meta($user_id, '_birthday', SB_Request::getString('birthday'));
		sb_update_user_meta($user_id, '_address', SB_Request::getString('address'));
		sb_update_user_meta($user_id, '_city', SB_Request::getString('city'));
		sb_update_user_meta($user_id, '_state', SB_Request::getString('state'));
		sb_update_user_meta($user_id, '_country', SB_Request::getString('country'));
		*/
		//sb_update_user_meta($user_id, '_image', $image_file);
		SB_Module::do_action('save_user', $user->user_id);
		//##update user
		SB_MessagesStack::AddMessage(SB_Text::_('Datos actualizados correctamente', 'users'), 'success');
		sb_redirect(SB_Route::_('index.php?mod=users'));
	}
}