<?php
?>
<form id="form-login" action="" method="post" class="row">
	<input type="hidden" name="mod" value="users" />
	<input type="hidden" name="task" value="recover_pwd" />
	<h3><?php print SB_Text::_('Recuperaci&oacute;n de Contrase&ntilde;a', '')?></h3>
	<div class="row">
		<div class="col-md-4">
			<div class="control-group">
				<input type="text" name="email" value="" class="form-control" placeholder="<?php print SB_Text::_('Su direccion de correo', 'users'); ?>" />
			</div>
		</div>
		<div class="col-md-1">
			<button type="submit" id="button-login" class="btn btn-success"><?php print SB_Text::_('Recuperar contrase&ntilde;a', 'users'); ?></button>
		</div>
	</div>
	
</form>