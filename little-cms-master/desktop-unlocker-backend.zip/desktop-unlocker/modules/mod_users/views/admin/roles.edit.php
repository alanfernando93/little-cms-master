<?php
?>
<div class="container">
	<h1><?php print $title; ?></h1>
	<form action="" method="post">
		<input type="hidden" name="mod" value="users" />
		<input type="hidden" name="task" value="roles.save" />
		<?php if( isset($role) ): ?>
		<input type="hidden" name="role_id" value="<?php print $role->role_id; ?>" />
		<?php endif; ?>
		<div class="row">
			<div class="col-md-4">
				<div class="form-group">
					<label><?php print SB_Text::_('Rol:', 'users'); ?></label>
					<input type="text" name="role_name" value="<?php print SB_Request::getString('role_name', isset($role) ? $role->role_name : ''); ?>" class="form-control" />
				</div>
			</div>
		</div>
		<div class="form-group">
			<label><?php print SB_Text::_('Descripci&oacute;n:', 'users'); ?></label>
			<textarea name="description" class="form-control"><?php print SB_Request::getString('role_name', isset($role) ? $role->role_description : ''); ?></textarea>
		</div>
		<div class="form-group">
			<label><?php print SB_Text::_('Permisos:', 'users'); ?></label>
			<div class="row">
			<?php foreach(sb_get_permissions() as $p): ?>
			<span class="col-md-2">
				<input type="checkbox" name="permissions[]" value="<?php print $p->permission_id; ?>" <?php print (isset($role) && $role->hasPermission($p->permission)) ? 'checked' : ''; ?> /><?php print $p->label; ?>
			</span>
			<?php endforeach; ?>
			</div>
		</div>
		<p>
			<a class="button primary" href="<?php print SB_Route::_('index.php?mod=users&view=roles'); ?>"><?php print SB_Text::_('Cancelar', 'users'); ?></a>
			<button class="button primary" type="submit"><?php print SB_Text::_('Guardar', 'users'); ?></button>
		</p>
	</form>
</div>