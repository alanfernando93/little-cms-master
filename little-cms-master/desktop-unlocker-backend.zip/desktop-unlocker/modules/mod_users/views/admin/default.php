<?php

?>
<div class="container">
	<h1><?php print SB_Text::_('Usuarios', 'users'); ?></h1>
	<ul class="view-buttons">
		<li><a class="button primary" href="index.php?mod=users&view=new_user"><?php print SB_Text::_('Nuevo', 'users'); ?></a></li>
	</ul>
	<table class="listing">
	<thead>
	<tr>
		<th>#</th>
		<th>&nbsp;</th>
		<th>
			<a href="<?php print $username_order_link; ?>">
				<?php print SB_Text::_('Usuario', 'users'); ?>
				<span class="glyphicon glyphicon-triangle-<?php print (SB_Request::getString('order_by') == 'username' && SB_Request::getString('order', 'asc') == 'asc') ? 'bottom' : 'top'; ?>"></span>
			</a>
		</th>
		<th>
			<a href="<?php print $name_order_link; ?>">
				<?php print SB_Text::_('Nombre', 'users'); ?>
				<span class="glyphicon glyphicon-triangle-<?php print (SB_Request::getString('order_by') == 'name' && SB_Request::getString('order', 'asc') == 'asc') ? 'bottom' : 'top'; ?>"></span>
			</a>
		</th>
		<th>
			<a href="<?php print $email_order_link; ?>">
				<?php print SB_Text::_('Email', 'users'); ?>
				<span class="glyphicon glyphicon-triangle-<?php print (SB_Request::getString('order_by') == 'email' && SB_Request::getString('order', 'asc') == 'asc') ? 'bottom' : 'top'; ?>"></span>
			</a>
		</th>
		<th>
			<a href="<?php print $rol_order_link; ?>">
				<?php print SB_Text::_('Rol', 'users'); ?>
				<span class="glyphicon glyphicon-triangle-<?php print (SB_Request::getString('order_by') == 'rol_name' && SB_Request::getString('order', 'asc') == 'asc') ? 'bottom' : 'top'; ?>"></span>
			</a>
		</th>
		<th><?php print SB_Text::_('Acciones', 'users'); ?></th>
	</tr>
	</thead>
	<tbody>
	<?php $i = 1; foreach($users as $user): ?>
	<?php 
	
	?>
	<tr>
		<td><?php print $i; ?></td>
		<td><img src="<?php print sb_get_user_image_url($user); ?>" alt="" width="60" class="img-thumbnail" /></td>
		<td><?php print $user->username; ?></td>
		<td><?php printf("%s %s", $user->first_name, $user->last_name); ?></td>
		<td><?php print $user->email; ?></td>
		<td><?php print $user->role_name; ?></td>
		<td>
			<a href="index.php?mod=users&view=edit_user&id=<?php print $user->user_id; ?>">Editar</a>
			<a href="index.php?mod=users&task=delete_user&id=<?php print $user->user_id; ?>" class="confirm" 
				data-message="<?php print SB_Text::_('Esta seguro de borrar el usuario?'); ?>">Borrar</a>
		</td>
	</tr>
	<?php $i++; endforeach; ?>
	</tbody>
	</table>
</div><!-- end class="container" -->

