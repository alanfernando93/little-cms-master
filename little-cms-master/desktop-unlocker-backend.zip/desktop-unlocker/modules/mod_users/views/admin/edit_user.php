<?php
$image = SB_Request::getString('imagefile', isset($user) ? sb_get_user_meta($user_id, '_image') : null);
$image_url = '';
if( !$image )
{
	$image_url = MODULE_URL . '/images/nobody.png';
}
elseif( isset($user) && file_exists($user_dir . SB_DS . $image) )
{
	$image_url = $user_url . '/' . $image;
}
else 
{
	$image_url = MODULE_URL . '/images/nobody.png';
}
$selected_role = SB_Request::getInt('role_id', isset($user) ? $user->role_id : -1);
$countries = sb_include('countries.php', 'file');
?>
<!-- <link rel="stylesheet" href="<?php print BASEURL;?>/js/fineuploader/fineuploader.css" /> -->
<div class="container">
	<h1><?php print $title; ?></h1>
	<div class="row">
		<form action="" method="post" enctype="multipart/form-data">
		<input type="hidden" name="mod" value="users" />
		<input type="hidden" name="task" value="save_user" />
		<?php if( isset($user) ): ?>
		<input type="hidden" name="user_id" value="<?php print $user_id; ?>" />
		<?php endif; ?>
		<input type="hidden" id="imagefile" name="imagefile" value="<?php print $image; ?>" />
		<div class="form-row">
			<div class="col-md-2">
				<div id="select-image"  title="<?php print SB_Text::_('Select user image', 'users'); ?>">
					<img src="<?php print $image_url; ?>" alt="" class="img-thumbnail" />
				</div>
				<div id="uploading" style="display:none;">
					<img src="<?php print BASEURL; ?>/js/fineuploader/loading.gif" alt=""  />
					<?php print SB_Text::_('Subiendo imagen...', 'users'); ?>
				</div>
			</div>
			<div class="col-md-10">
				<div class="form-row row">
					<label><?php print SB_Text::_('Nombres:', 'users'); ?></label>
					<input type="text" name="first_name" value="<?php print SB_Request::getString('first_name', isset($user) ? $user->first_name : ''); ?>" class="form-control" />
				</div>
				<div class="form-row row">
					<label><?php print SB_Text::_('Apellidos:', 'users'); ?></label>
					<input type="text" name="last_name" value="<?php print SB_Request::getString('last_name', isset($user) ? $user->last_name : ''); ?>" class="form-control" />
				</div>
			</div>
			<div class="clear"></div>
		</div>
		<div id="user-tabs">
		  	<ul class="nav nav-tabs" role="tablist">
			    <li role="presentation" class="active">
			    	<a href="#profile" aria-controls="home" role="tab" data-toggle="tab"><?php print SB_Text::_('Perfil', 'users'); ?></a>
			    </li>
			    <li role="presentation"><a href="#personal" aria-controls="profile" role="tab" data-toggle="tab">Personal</a></li>
			    <?php SB_Module::do_action('user_tabs', isset($user) ? $user : null); ?>
		  	</ul>
		  	<!-- Tab panes -->
		  	<div class="tab-content">
			    <div role="tabpanel" class="tab-pane active" id="profile">
			    	<?php SB_Module::do_action('before_user_tab_personal'); ?>
			    	<div class="row">
			    		<div class="col-md-4">
				    		<div class="form-group">
					    		<label for="email">Email:</label>
		    					<input type="email" class="form-control" id="email" placeholder="Email" name="email" value="<?php print SB_Request::getString('first_name', isset($user) ? $user->email : ''); ?>">
					    	</div>
				    	</div>
				    	<div class="col-md-4">
				    		<div class="form-group">
					    		<label for="pwd"><?php print SB_Text::_('Contrase&ntilde;a:', 'users'); ?></label>
		    					<input type="password" class="form-control" id="pwd" name="pwd" value="">
					    	</div>
				    	</div>
				    	<div class="col-md-2">
				    		<div class="form-group">
					    		<label for="creation_date"><?php print SB_Text::_('Fecha Creaci&oacute;n:', 'users'); ?></label>
					    		<?php if( isset($user) ): ?>
		    					<input type="text" class="form-control datepicker" id="creation_date" name="creation_date" 
		    							value="<?php print sb_format_date($user->creation_date); ?>" />
		    					<?php else: ?>
		    					<input type="text" class="form-control datepicker" id="creation_date" name="creation_date" 
		    							value="<?php print sb_format_date(date('Y-m-d')); ?>" />
		    					<?php endif; ?>
					    	</div>
				    	</div>
			    	</div>
			    	<div class="col-md-6">
			    		<div class="row form-group">
				    		<label for="role_id"><?php print SBText::_('Rol de Usuario:', 'users');?></label>
	    					<select id="role_id" name="role_id" class="form-control">
	    						<option value="-1"><?php print SBText::_('-- rol --', 'users'); ?></option>
	    						<?php foreach($roles as $role): ?>
	    						<option value="<?php print $role->role_id; ?>" <?php print ($selected_role == $role->role_id) ? 'selected' : ''; ?>>
	    							<?php print $role->role_name; ?>
	    						</option>
	    						<?php endforeach; ?>
	    						<option></option>
	    					</select>
				    	</div>
			    	</div>
			    	<div class="clearfix"></div>
			    	<div class="form-group">
			    		<label for="observations"><?php print SBText::_('Observaciones:', 'users'); ?></label>
    					<textarea class="form-control" id="observations" name="observations"><?php print SB_Request::getString('observations', isset($user) ? sb_get_user_meta($user->user_id, '_observations') : ''); ?></textarea>
			    	</div>
			    	<div class="form-group">
			    		<label for="notes"><?php print SBText::_('Notas:', 'users'); ?></label>
    					<textarea class="form-control" id="notes" placeholder="" name="notes"><?php print SB_Request::getString('observations', isset($user) ? sb_get_user_meta($user->user_id, '_notes') : ''); ?></textarea>
			    	</div>
			    	<?php SB_Module::do_action('after_user_tab_personal', isset($user) ? $user : null); ?>
			    </div>
			    <div role="tabpanel" class="tab-pane" id="personal">
			    	<div class="col-md-4 form-group">
			    		<div class="row">
				    		<label><?php print SB_Text::_('Fecha de Nacimiento:', 'users')?></label>
				    		<input class="form-control datepicker" type="text" name="birthday" value="<?php print SB_Request::getString('birthday', isset($user) ? $user->_birthday : ''); ?>" />
			    		</div>
			    	</div>
			    	<div class="clearfix"></div>
			    	<div class="form-group">
			    		<label><?php print SB_Text::_('Direccion:', 'users')?></label>
			    		<input class="form-control" type="text" name="address" value="<?php print SB_Request::getString('address', isset($user) ? $user->_address : ''); ?>" />
			    	</div>
			    	<div class="col-md-4 form-group">
			    		<div class="row">
				    		<label><?php print SB_Text::_('Ciudad:', 'users')?></label>
				    		<input class="form-control" type="text" name="city" value="<?php print SB_Request::getString('city', isset($user) ? $user->_city : ''); ?>" />
				    	</div>
			    	</div>
			    	<div class="col-md-4 form-group">
			    		<div class="ro">
			    			<label><?php print SB_Text::_('Provincia:', 'users')?></label>
			    			<input class="form-control" type="text" name="state" value="<?php print SB_Request::getString('state', isset($user) ? $user->_state : ''); ?>" />
			    		</div>
			    	</div>
			    	<div class="col-md-4 form-group">
			    		<div class="ro">
				    		<label><?php print SB_Text::_('Pais:', 'users')?></label>
				    		<select name="country" class="form-control">
				    			<option value="-1"><?php print SB_Text::_('-- pais --', 'users'); ?></option>
				    			<?php foreach($countries as $code => $label): ?>
				    			<option value="<?php print $code; ?>" <?php print isset($user) && $user->_country == $code ? 'selected' : ''; ?>><?php print $label; ?></option>
				    			<?php endforeach; ?>
				    		</select>
			    		</div>
			    	</div>
			    	<div class="clearfix"></div>
			    </div>
			    <?php SB_Module::do_action('user_tabs_content', isset($user) ? $user : null); ?>
		  	</div>
		</div><br/>
		<p>
			<a href="index.php?mod=users" class="button primary"><?php print SBText::_('Cancelar', 'users'); ?></a>
			<button type="submit" class="button primary"><?php print SBText::_('Guardar', 'users'); ?>r</button>
		</p>
	</form>
	</div>
</div>
<script>
jQuery(function()
{
	var uploader = new qq.FineUploaderBasic({
		//element: document.getElementById("uploader"),
		//template: 'qq-template-gallery',
		button: document.getElementById('select-image'),
		request: {
			endpoint: '<?php print $upload_endpoint; ?>'
		},
		validation: {
			allowedExtensions: ['jpeg', 'jpg', 'gif', 'png']
		},
		callbacks: 
		{
			onSubmit: function(id, fileName) 
			{
				//$messages.append('<div id="file-' + id + '" class="alert" style="margin: 20px 0 0"></div>');
			},
			onUpload: function(id, fileName) 
			{
				jQuery('#uploading').css('display', 'block');
			},
			onProgress: function(id, fileName, loaded, total) 
			{
				/*
				if (loaded < total) 
				{
					progress = Math.round(loaded / total * 100) + '% of ' + Math.round(total / 1024) + ' kB';
	              	jQuery('#file-' + id).removeClass('alert-info')
	                              .html('<img src="client/loading.gif" alt="In progress. Please hold."> ' +
	                                    'Uploading ' +
	                                    '“' + fileName + '” ' +
	                                    progress);
				} 
				else 
				{
					jQuery('#file-' + id).addClass('alert-info')
	                              .html('<img src="client/loading.gif" alt="Saving. Please hold."> ' +
	                                    'Saving ' +
	                                    '“' + fileName + '”');
	            }
	            */
			},
			onComplete: function(id, fileName, responseJSON) 
			{
				jQuery('#uploading').css('display', 'none');
				if (responseJSON.success) 
				{
					jQuery('#select-image img:first').attr('src', responseJSON.image_url);
					jQuery('#imagefile').val(responseJSON.uploadName);
	            } 
	            else 
				{
					alert(responseJSON.error);
	            }
			}
		}
	});
});
jQuery('#user-tabs .nav-tabs li a').click(function (e) 
{
	e.preventDefault();
	jQuery(this).tab('show');
});
</script>
