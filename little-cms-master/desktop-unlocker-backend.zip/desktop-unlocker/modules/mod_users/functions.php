<?php
function sb_get_user_meta($user_id, $meta_key)
{
	return SB_Meta::getMeta('user_meta', $meta_key, 'user_id', $user_id);
}
function sb_add_user_meta($user_id, $meta_key, $meta_value)
{
	return SB_Meta::addMeta('user_meta', $meta_key, $meta_value, 'user_id', $user_id);
}
function sb_update_user_meta($user_id, $meta_key, $meta_value)
{
	return SB_Meta::updateMeta('user_meta', $meta_key, $meta_value, 'user_id', $user_id);
}
/**
 * 
 * @return SB_User
 */
function sb_get_current_user()
{
	static $user =  null;
	$var_name = defined('LT_ADMIN') ? 'admin_user' : 'user';
	if( $user == null )
	{
		$user = new SB_User();
		$user->SetDbData(SB_Session::getVar($var_name));
		$user->GetDbPermissions();
	}
	return $user;
}
function sb_get_user_image_url($user_id)
{
	$placeholder = sb_get_module_url('users') . '/images/nobody.png';
	
	if( is_int($user_id) )
		$user = new SB_User($user_id);
	else 
		$user = $user_id;
	
	if( !$user->user_id )
		return $placeholder;
	$user_dir = UPLOADS_DIR . SB_DS . sb_build_slug($user->username);
	$user_url = UPLOADS_URL . '/' . sb_build_slug($user->username);
	$image_filename = sb_get_user_meta($user->user_id, '_image');
	if( empty($image_filename) || !file_exists($user_dir . SB_DS . $image_filename) )
	{
		return $placeholder;
	}
	return $user_url . '/' . $image_filename;
}
function sb_get_user_roles()
{
	$dbh = SB_Factory::getDbh();
	$query = "SELECT * FROM user_roles";
	$dbh->Query($query);
	$roles = array();
	foreach($dbh->FetchResults() as $row)
	{
		$role = new SB_Role();
		$role->SetDbData($row);
		$roles[] = $role;
	}
	return $roles;
}