<?php
class LT_AdminControllerDashboard extends SB_Controller
{
	public function task_default()
	{
		
	}
}