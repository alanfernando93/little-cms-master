<?php
class SB_ModulesHelper
{
	public static function permissionExists($permission)
	{
		$dbh = SB_Factory::getDbh();
		$query = "";
		$dbh->Query($query);
	}
}