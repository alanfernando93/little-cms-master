<?php
?>
<div class="container">
	<h2><?php print $title; ?></h2>
	<form action="" method="post">
		<input type="hidden" name="mod" value="unlocker" />
		<input type="hidden" name="task" value="save_client" />
		<?php if( isset($client) ): ?>
		<input type="hidden" name="id" value="<?php print $client->client_id; ?>" />
		<?php endif; ?>
		<div class="col-md-6">
			<div class="control-group">
				<label><?php print SBText::_('Username', 'unlocker'); ?></label>
				<input type="text" name="username" value="<?php print isset($client) ? $client->username : ''; ?>" required class="form-control" />
			</div>
			<div class="control-group">
				<label><?php print SBText::_('Password', 'unlocker'); ?></label>
				<input type="password" name="pwd" value="<?php print ''; ?>" class="form-control" placeholder="<?php print $pwd_placeholder; ?>" />
			</div>
			<div class="control-group">
				<label><?php print SBText::_('Unique Machine Key', 'unlocker'); ?></label>
				<input type="text" name="machine_key" value="<?php print isset($client) ? $client->machine_key : ''; ?>" class="form-control" />
			</div>
			<div class="control-group">
				<label><?php print SBText::_('Application Branding', 'unlocker'); ?></label>
				<input type="text" name="app_branding" value="<?php print isset($client) ? $client->data->app_branding : ''; ?>" required class="form-control" />
			</div>
			<div class="control-group">
				<label><?php print SBText::_('Client Branding', 'unlocker'); ?></label>
				<input type="text" name="client_branding" value="<?php print isset($client) ? $client->data->client_branding : ''; ?>" class="form-control" />
			</div>
		</div>
		<div class="col-md-6">
			<div class="control-group">
				<label><?php print SBText::_('Subscription Length:', 'unlocker'); ?></label>
				<input type="text" name="subscription_length" value="<?php print isset($client) ? sb_format_date($client->subscription_ends) : ''; ?>" class="datepicker form-control" />
			</div>
			<div class="control-group">
				<label><?php print SBText::_('Status', 'unlocker'); ?></label>
				<select name="status" class="form-control">
					<option value="-1"><?php print SBText::_('-- status --', 'unlocker'); ?></option>
					<option value="waiting_machine_key" <?php print isset($client) && $client->status == 'waiting_machine_key' ? 'selected':''; ?>><?php print SBText::_('Waiting Machine Key', 'unlocker'); ?></option>
					<option value="active" <?php print isset($client) && $client->status == 'active' ? 'selected':''; ?>><?php print SBText::_('Active', 'unlocker'); ?></option>
					<option value="inactive" <?php print isset($client) && $client->status == 'inactive' ? 'selected':''; ?>><?php print SBText::_('Inactive', 'unlocker'); ?></option>
					<option value="expired" <?php print isset($client) && $client->status == 'expired' ? 'selected':''; ?>><?php print SBText::_('Expired', 'unlocker'); ?></option>
				</select>
			</div>
		</div>
		<div class="clearfix"></div><br/>
		<p>
			<a href="<?php print SB_Route::_('index.php?mod=unlocker'); ?>" class="button primary"><?php print SBText::_('Cancel', 'unlocker'); ?></a>
			<button type="submit" class="button primary"><?php print SBText::_('Save', 'unlocker'); ?></button>
		</p>
	</form>
</div>
