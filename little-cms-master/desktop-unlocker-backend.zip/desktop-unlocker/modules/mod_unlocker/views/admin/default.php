<?php
?>
<div class="container">
	<h2><?php print SBText::_('Unlocker Clients', 'unlocker'); ?></h2>
	<ul class="view-button">
		<li><a class="button primary" href="<?php print SB_Route::_('index.php?mod=unlocker&view=new_client'); ?>"><?php print SBText::_('New'); ?></a></li>
	</ul>
	<table class="table">
	<thead>
	<tr>
		<th>#</th>
		<th><?php print SBText::_('Client'); ?></th>
		<th><?php print SBText::_('Email'); ?></th>
		<th><?php print SBText::_('Username'); ?></th>
		<th><?php print SBText::_('Machine Key'); ?></th>
		<th><?php print SBText::_('Action'); ?></th>
	</tr>
	</thead>
	<tbody>
	<?php $i = 1; foreach($clients as $c): ?>
	<tr>
		<td><?php print $i; ?></td>
		<td><?php printf("%s %s", $c->first_name, $c->last_name); ?></td>
		<td></td>
		<td><?php print $c->username; ?></td>
		<td><?php print $c->machine_key; ?></td>
		<td>
			<a href="<?php print SB_Route::_('index.php?mod=unlocker&view=edit_client&id='.$c->client_id); ?>">
				<?php print SBText::_('Edit'); ?></a> |
			<a href="<?php print SB_Route::_('index.php?mod=unlocker&task=delete_client&id'.$c->client_id); ?>"
				class="confirm" data-message="<?php print SBText::_('Are you sure to delete the customer?')?>">
				<?php print SBText::_('Delete'); ?>
			</a>
		</td>
	</tr>
	<?php $i++; endforeach; ?>
	</tbody>
	</table>
</div>