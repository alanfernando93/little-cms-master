<?php
defined('BASEPATH') or die('Dont fuck with me buddy.');
SB_Module::RunSQL('unlocker');
$dbh = SB_Factory::getDbh();
$permissions = array(
		array('permission' => 'manage_unlocker_clients', 'label'	=> SB_Text::_('Manage DUnlocker Clients', 'statistics')),
);
$local_permissions = sb_get_permissions(false);
foreach($permissions as $perm)
{
	if( in_array($perm['permission'], $local_permissions) ) continue;
	$dbh->Insert('permissions', $perm);
}
