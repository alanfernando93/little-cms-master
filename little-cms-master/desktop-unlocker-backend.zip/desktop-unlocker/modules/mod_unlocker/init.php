<?php
class LT_ModuleUnlocker
{
	public function __construct()
	{
		$this->AddActions();
	}
	public function AddActions()
	{
		if( defined('LT_ADMIN') )
		{
			SB_Module::add_action('admin_menu', array($this, 'action_admin_menu'));
		}
	}
	public function action_admin_menu()
	{
		SB_Menu::addMenuChild('menu-management', SBText::_('Desktop Clients', 'unlocker'), SB_Route::_('index.php?mod=unlocker'), 'desktop-unlocker-menu');
	}
}
new LT_ModuleUnlocker();