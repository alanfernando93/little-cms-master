CREATE TABLE IF NOT EXISTS unlocker_clients(
	client_id			bigint not null auto_increment primary key,
	first_name			varchar(128),
	last_name			varchar(128),
	email				varchar(128),
	username			varchar(128),
	pwd					varchar(256),
	machine_key			varchar(256),
	api_key				text,
	subscription_starts	bigint,
	subscription_ends	bigint,
	data				text,
	status				varchar(64),
	creation_date		datetime,
	creation_time		bigint
);
