<?php
class LT_AdminControllerUnlocker extends SB_Controller
{
	public function task_default()
	{
		$dbh = SB_Factory::getDbh();
		$query = "SELECT * FROM unlocker_clients ORDER BY creation_date DESC";
		$dbh->Query($query);
		$clients = $dbh->FetchResults();
		
		sb_set_view_var('clients', $clients);
		
	}
	public function task_new_client()
	{
		sb_set_view_var('title', SBText::_('Create New Unlocker Client', 'unlocker'));
		sb_set_view_var('pwd_placeholder', SBText::_('The client password'));
	}
	public function task_edit_client()
	{
		$id = SB_Request::getInt('id');
		if( !$id )
		{
			sb_redirect(SB_Route::_('index.php?mod=unlocker'));
		}
		$query = "SELECT * FROM unlocker_clients WHERE client_id = $id LIMIT 1";
		$dbh = SB_Factory::getDbh();
		if( !$dbh->Query($query) )
		{
			SB_MessagesStack::AddMessage(SBText::_('The client does not exists.', 'unlocker'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=unlocker'));
		}
		$client = $dbh->FetchRow();
		if( !empty($client->data) )
		{
			$client->data = json_decode($client->data);
		}
		sb_set_view('new_client');
		sb_set_view_var('title', SBText::_('Edit Unlocker Client', 'unlocker'));
		sb_set_view_var('pwd_placeholder', SBText::_('Leave blank for no update'));
		sb_set_view_var('client', $client);
	}
	public function task_save_client()
	{
		
		$id = SB_Request::getInt('id');
		$current_task = $id ? 'task_edit_client' : 'task_new_client';
		//$first_name = SB_Request::getString('first_name');
		//$last_name = SB_Request::getString('last_name');
		$username 			= SB_Request::getString('username');
		$pwd				= SB_Request::getString('pwd');
		$machine_key		= SB_Request::getString('machine_key');
		$app_branding		= SB_Request::getString('app_branding');
		$client_branding	= SB_Request::getString('client_branding');
		$subscription_length	= SB_Request::getString('subscription_length');
		$status					= SB_Request::getString('status', 'inactive');
		if( !$id && empty($username) )
		{
			SB_MessagesStack::AddMessage(SBText::_('Enter a username'), 'error');
			$this->$current_task();
			return false;
		}
		if( !$id && empty($pwd) )
		{
			SB_MessagesStack::AddMessage(SBText::_('Enter a user password'), 'error');
			$this->$current_task();
			return false;
		}
		/*
		if( empty($machine_key) )
		{
			SB_MessagesStack::AddMessage(SBText::_('Enter a user password'), 'error');
			$this->$current_task();
			return false;
		}
		*/
		if( empty($status) || $status == -1 )
		{
			SB_MessagesStack::AddMessage(SBText::_('You need to select a client status'), 'error');
			$this->$current_task();
			return false;
		}
		$dbh = SB_Factory::getDbh();
		if( !$id )
		{
			$username = $dbh->EscapeString($username);
			$query = "SELECT client_id FROM unlocker_clients WHERE username = '$username' LIMIT 1";
			if( $dbh->Query($query) )
			{
				SB_MessagesStack::AddMessage(SBText::_('The username already exists', 'unlocker'), 'error');
				$this->$current_task();
				return false;
			}
		}
		$subscription_ends = strtotime($subscription_length);
		$data = compact('machine_key', 'subscription_ends', 'status');
		$client_data = array(
				'app_branding'		=> $app_branding,
				'client_branding' 	=> $client_branding
		);
		$data['data']			= json_encode($client_data);
		if( !$id )
		{
			$data['username']		= $username;
			$data['pwd']			= md5($pwd);
			$data['creation_date'] 	= date('Y-m-d H:i:s');
			$data['creation_time'] 	= time();
			
			$id = $dbh->Insert('unlocker_clients', $data);
			SB_MessagesStack::AddMessage(SBText::_('The clent has been created', 'unlocker'), 'success');
			sb_redirect(SB_Route::_('index.php?mod=unlocker'));
		}
		else
		{
			if( !empty($pwd) )
			{
				$data['pwd'] = md5($pwd);
			}
			$dbh->Update('unlocker_clients', $data, array('client_id' => $id));
			SB_MessagesStack::AddMessage(SBText::_('The clent has been updated', 'unlocker'), 'success');
			sb_redirect(SB_Route::_('index.php?mod=unlocker&view=edit_client&id='.$id));
		}
	}
}
