<?php
class LT_ControllerUnlocker extends SB_Controller
{
	public function task_authenticate()
	{
		header('Content-type: application/json');
		$username 	= SB_Request::getString('username');
		$pwd		= SB_Request::getString('pwd');
		$machine_key = SB_Request::getString('machine_key');
		if( empty($username) )
			die('{"ERROR":"Username invalid"}');
		if( empty($pwd) )
			die('{"ERROR":"Password invalid"}');
		$dbh = SB_Factory::getDbh();
		$username = $dbh->EscapeString($username);
		$query = "SELECT * FROM unlocker_clients WHERE username = '$username' ".
					//"AND (status = 'active' OR status = 'waiting_machine_key') ".
					"LIMIT 1";
		if( $dbh->Query($query) <= 0 )
			die('{"ERROR":"Username or password incorrect."}');
		$client = $dbh->FetchRow();
		//##validate password
		if( $client->pwd != md5($pwd) )
			die('{"ERROR":"Username or password incorrect."}');
		//##normalize client data
		$client->client_id 				= (int)$client->client_id;
		$client->subscription_starts 	= (int)$client->subscription_starts;
		$client->subscription_ends 		= (int)$client->subscription_ends;
		$client->creation_time 			= (int)$client->creation_time;
		$client->data					= (object)json_decode($client->data);
		
		$ctime = time();
		$allowed = true;
		$msg = '';
		
		//##check machine key
		if( $client->status == 'waiting_machine_key' )
		{
			$res = array(
					'CLIENT' 				=> $client,
					'SUBSCRIPTION_STATUS'	=> $client->status,
					'ALLOWED'				=> $allowed,
					'MESSAGE'				=> $msg
			);
			die(json_encode($res));
		}
		if( $client->machine_key != $machine_key  )
		{
			die('{"ERROR":"Invalid licence key."}');
		}
		//##check subscription 
		if( $ctime > (int)$client->subscription_ends )
		{
			$dbh->Update('unlocker_clients', array('status' => 'expired'), array('client_id' => $client->client_id));
			$client->status = 'expired';
			$allowed = false;
			$msg = SBText::_('Your subcription has expired. The application will ends now', 'unlocker');
			$res = array(
					'CLIENT' 				=> $client,
					'SUBSCRIPTION_STATUS'	=> $client->status,
					'ALLOWED'				=> $allowed,
					'MESSAGE'				=> $msg
			);
			die(json_encode($res));
		}
		if( $client->status == 'active' )
		{
			$res = array(
					'CLIENT' 				=> $client,
					'SUBSCRIPTION_STATUS'	=> $client->status,
					'ALLOWED'				=> $allowed,
					'MESSAGE'				=> $msg
			);
			die(json_encode($res));
		}
	}
	public function task_set_machine_key()
	{
		$username 	= SB_Request::getString('username');
		$pwd		= SB_Request::getString('pwd');
		$machine_key	= SB_Request::getString('machine_key');
		if( empty($username) )
			die('{"ERROR":"Username invalid"}');
		if( empty($pwd) )
			die('{"ERROR":"Password invalid"}');
		$dbh = SB_Factory::getDbh();
		$username = $dbh->EscapeString($username);
		$query = "SELECT * FROM unlocker_clients WHERE username = '$username' AND status = 'waiting_machine_key' LIMIT 1";
		if( $dbh->Query($query) <= 0 )
			die('{"ERROR":"Username or password incorrect."}');
		$client = $dbh->FetchRow();
		//##validate password
		if( $client->pwd != md5($pwd) )
			die('{"ERROR":"Username or password incorrect."}');
		
		if( empty($client->machine_key) )
		{
			$dbh->Update('unlocker_clients', array('machine_key' => $machine_key, 'status' => 'active'), array('client_id' => $client->client_id));
		}
		
	}
}
