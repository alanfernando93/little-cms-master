<?php
class LT_AdminControllerSettings extends SB_Controller
{
	public function task_default()
	{
		sb_set_view_var('settings', sb_get_parameter('settings', new stdClass()));
	}
	public function task_save()
	{
		$settings = SB_Request::getVar('settings');
		$dbh = SB_Factory::getDbh();
		sb_update_parameter('settings', $settings);
		SB_Module::do_action('save_settings');
		SB_MessagesStack::AddMessage(SB_Text::_('La configuracion se ha guardado correctamente.'), 'success');
		sb_redirect(SB_Route::_('settings.php'));
	}
}