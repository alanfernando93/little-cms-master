<?php
//$continents = array( 'Africa', 'America', 'Antarctica', 'Arctic', 'Asia', 'Atlantic', 'Australia', 'Europe', 'Indian', 'Pacific');
//$time_zones = timezone_identifiers_list();
//print_r($time_zones);
?>
<div class="container">
	<h1><?php print SB_Text::_('Configuraci&oacute;n', 'settings'); ?></h1>
	<div id="settings-tabs">
		<ul class="nav nav-tabs" role="tablist">
			<?php if( sb_get_current_user()->can('manage_general_settings') ): ?>
		    <li class="active"><a href="#general" role="tab" data-toggle="tab"><?php print SB_Text::_('General', 'settings'); ?></a></li>
		    <?php endif; ?>
		    <?php SB_Module::do_action('settings_tabs', $settings); ?>
	  	</ul>
	  	<form action="" method="post">
	  		<input type="hidden" name="mod" value="settings" />
	  		<input type="hidden" name="task" value="save" />
	  		<div class="tab-content">
	  			<?php if( sb_get_current_user()->can('manage_general_settings') ): ?>
		  		<div id="general" role="tabpanel" class="tab-pane active">
		  			<div class="control-group">
		  				<label><?php print SB_Text::_('Titulo del Sitio:', 'settings'); ?></label>
		  				<input type="text" name="settings[SITE_TITLE]" value="<?php print @$settings->SITE_TITLE; ?>" class="form-control" />
		  			</div>
		  			<div class="control-group">
		  				<label><?php print SB_Text::_('Zona horaria:', 'settings'); ?></label>
		  				<select name="settings[TIME_ZONE]" class="form-control">
		  					<?php print sb_timezone_choice(@$settings->TIME_ZONE); ?>
		  				</select>
		  			</div>
		  			<div class="control-group">
		  				<label><?php print SB_Text::_('Formato Fecha:', 'settings'); ?></label>
		  				<select name="settings[DATE_FORMAT]" class="form-control">
		  					<option value="Y-m-d" <?php print (isset($settings->DATE_FORMAT) && $settings->DATE_FORMAT == 'Y-m-d' ) ? 'selected' : ''; ?>>yyyy-mm-dd</option>
		  					<option value="m-d-Y" <?php print (isset($settings->DATE_FORMAT) && $settings->DATE_FORMAT == 'm-d-Y' ) ? 'selected' : ''; ?>>mm-dd-yyyy</option>
		  					<option value="d-m-Y" <?php print (isset($settings->DATE_FORMAT) && $settings->DATE_FORMAT == 'd-m-Y' ) ? 'selected' : ''; ?>>dd-mm-yyyy</option>
		  				</select>
		  			</div>
		  		</div>
		  		<?php endif; ?>
		  		<?php SB_Module::do_action('settings_tabs_content', $settings); ?>
		  	</div>
		  	<br/>
		  	<p>
		  		<button class="button primary" type="submit"><?php print SB_Text::_('Guardar', 'settings'); ?></button>
		  	</p>
	  	</form>
	</div>
</div>
<script>
jQuery('#settings-tabs .nav-tabs a').click(function (e) 
{
	e.preventDefault()
	jQuery(this).tab('show')
});
</script>