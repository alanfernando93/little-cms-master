<?php
/**
 * db user: thecelm0_dunlock
 * db pass: tPAx6ar_dywC
 * @author marcelo
 *
 */
class SB_ApplicationDesktopunlocker extends SB_Application
{
	public function Load()
	{
		parent::Load();
		$this->defaultModules[] = 'mod_unlocker';
	}
}