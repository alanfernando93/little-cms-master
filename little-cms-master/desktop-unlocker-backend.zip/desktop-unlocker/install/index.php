<?php
define('LT_INSTALL', 1);
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'init.php';
$task = isset($_REQUEST['task']) ? $_REQUEST['task'] : null;
if( $task == 'test_connection' )
{
	function __sb_catch_error($errno, $errstr, $errfile, $errline, $errcontext)
	{
		throw new Exception("[$errno]: ".$errstr, $errno);
	}
	set_error_handler('__sb_catch_error');
	$res = array('status' => 'ok', 'message' => SB_Text::_('Conexion exitosa'));
	try 
	{
		$dbh = new SB_MySQL($_POST['server'], $_POST['db_user'], $_POST['db_pass']);
		$dbh->selectDB($_POST['db_name']);
		$dbh->Close();
	}
	catch(Exception $e)
	{
		$res['status'] 	= 'error';
		$res['error']	= $e->getMessage();
	}
	restore_error_handler();
	header('Content-type: application/json');
	die(json_encode($res));
}
elseif( $task == 'do_install' )
{
	$dbh = null;
	function __sb_catch_error($errno, $errstr, $errfile, $errline, $errcontext)
	{
		throw new Exception("[$errno]: ".$errstr, $errno);
	}
	set_error_handler('__sb_catch_error');
	try
	{
		$db_host		= trim($_POST['db_host']);
		$db_name		= trim($_POST['db_name']);
		$db_username	= trim($_POST['db_username']);
		$db_pwd			= trim($_POST['db_pwd']);
		$root_pwd 		= trim($_POST['root_pwd']);
		$base_url		= trim($_POST['base_url']);
		$pass			= true;
		
		if( empty($db_host) )
		{
			SB_MessagesStack::AddMessage(SB_Text::_('Debe ingresar el servidor de base de datos.'), 'error');
			$pass = false;
		}
		if( empty($db_name) )
		{
			SB_MessagesStack::AddMessage(SB_Text::_('Debe ingresar el nombre de la base de datos.'), 'error');
			$pass = false;
		}
		if( empty($db_username) )
		{
			SB_MessagesStack::AddMessage(SB_Text::_('Debe ingresar el usuario de base de datos.'), 'error');
			$pass = false;
		}
		if( empty($root_pwd) )
		{
			SB_MessagesStack::AddMessage(SB_Text::_('Debe ingresar una contrase&ntilde;a para root.'), 'error');
			$pass = false;
		}
		if( $pass )
		{
			//$cfg_file 		= file_exists(dirname(dirname(__FILE__)) . SB_DS . 'config.php') ? 'config.php' : 'config-min.php';
			$cfg_file 		= dirname(dirname(__FILE__)) . SB_DS . 'config-min.php';
			$new_cfg_file	= dirname(dirname(__FILE__)) . SB_DS . 'config.php';
			//##write config file
			$fh 		= fopen($cfg_file, 'r');
			$cfg_fh 	= fopen($new_cfg_file, 'w+');
			while( $line = fgets($fh) )
			{
				if( strstr($line, 'DB_SERVER') )
				{
					fwrite($cfg_fh, "define('DB_SERVER', '$db_host');\n");
				}
				elseif( strstr($line, 'DB_NAME') )
				{
					fwrite($cfg_fh, "define('DB_NAME', '$db_name');\n");
				}
				elseif( strstr($line, 'DB_USER') )
				{
					fwrite($cfg_fh, "define('DB_USER', '$db_username');\n");
				}
				elseif( strstr($line, 'DB_PASS') )
				{
					fwrite($cfg_fh, "define('DB_PASS', '$db_pwd');\n");
				}
				elseif( strstr($line, "'BASEURL'") )
				{
					fwrite($cfg_fh, "define('BASEURL', '$base_url');\n");
				}
				else
				{
					fwrite($cfg_fh, $line);
				}
			}
			fclose($fh);
			fclose($cfg_fh);
			SB_Session::setVar('root_pwd', $root_pwd);
			header('Location: success.php');die();
		}
		
	}
	catch(Exception $e)
	{
		print $e->getMessage();
	}
}
$host = $_SERVER['HTTP_HOST'];
$base_url = 'http://' . $host . dirname(dirname($_SERVER['SCRIPT_NAME']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title></title>
	<meta charset="utf-8" />
	<link href="../js/bootstrap-3.3.5/css/bootstrap.min.css" rel="stylesheet" />
	<link href="../js/bootstrap-3.3.5/css/bootstrap-theme.min.css" rel="stylesheet" />
	<script src="../js/jquery.min.js"></script>
	<script src="../js/bootstrap-3.3.5/js/bootstrap.min.js"></script>
	<script>
	var cms = 
	{
		check_connection: function(server, db_name, db_user, db_pass)
		{
			var params = 'task=test_connection&server='+server+'&db_name='+db_name+'&db_user='+db_user+'&db_pass='+db_pass;
			jQuery.post('index.php', params, function(res)
			{
				if( res.status == 'ok' )
				{
					alert(res.message);
					jQuery('#collapse-database').collapse('hide');
					jQuery('#collapse-admin-cfg').collapse('show');
				}
				else
				{
					alert(res.error);
				}
			});
			
		}
	};
	jQuery(function()
	{
		jQuery('#btn-check-connection').click(function()
		{
			var server 	= jQuery('#db_host').val().trim();
			var db_name = jQuery('#db_name').val().trim();
			var db_user = jQuery('#db_username').val().trim();
			var db_pass = jQuery('#db_pwd').val().trim();
			
			if( server.length <= 0 )
			{
				alert('<?php print SB_Text::_('Debe ingresar el servidor de base de datos'); ?>');
				jQuery('#db_host').focus();
				return false;
			}
			if( db_name.length <= 0 )
			{
				alert('<?php print SB_Text::_('Debe ingresar el nombre de la base de datos'); ?>');
				jQuery('#db_name').focus();
				return false;
			}
			if( db_user.length <= 0 )
			{
				alert('<?php print SB_Text::_('Debe ingresar el usuario de base de datos'); ?>');
				jQuery('#db_username').focus();
				return false;
			}
			cms.check_connection(server, db_name, db_user, db_pass);
			
			return false;
		});
	});
	</script>
</head>
<body>
<div class="container-fluid">
	<div class="row">
		<div id="content" class="col-md-10 col-md-offset-1">
			<div class="jumbotron">
				<h1><?php print SB_Text::_('Bienvenido a la installacion de Little CMS.'); ?></h1>
			</div>
			<form action="" method="post" class="form-horizontal">
				<input type="hidden" name="task" value="do_install" />
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div id="panel-licence" class="panel panel-default">
				    	<div id="headingOne" class="panel-heading" role="tab" >
					      	<h4 class="panel-title">
					          	<?php print SB_Text::_('Acuerdo de licencia'); ?>
					      	</h4>
				    	</div>
				    	<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
				      		<div class="panel-body">
				        		Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, 
				        		non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, 
				        		sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, 
				        		craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. 
				        		Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them 
				        		accusamus labore sustainable VHS.
				        		<p class="text-right">
				        			<a href="javascript:;" onclick="jQuery('#collapseOne').collapse('hide');jQuery('#collapse-database').collapse('show');" class="btn btn-primary"><?php print SB_Text::_('Siguiente'); ?></a>
				        		</p>
				      		</div>
				    	</div>
				  	</div><!-- end id="panel-licence" -->
				  	<div id="panel-database" class="panel panel-default">
				    	<div class="panel-heading" role="tab" id="headingTwo">
				      		<h4 class="panel-title"><?php print SB_Text::_('Configuracion Base de Datos'); ?></h4>
				    	</div>
				    	<div id="collapse-database" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
				      		<div class="panel-body">
				      			<div class="form-group">
								    <label for="db_host" class="col-sm-2 control-label"><?php print SB_Text::_('Servidor:'); ?></label>
								    <div class="col-sm-10">
								    	<input type="text" class="form-control" id="db_host" name="db_host" value="" placeholder="">
								    </div>
								</div>
				        		<div class="form-group">
								    <label for="db_name" class="col-sm-2 control-label"><?php print SB_Text::_('Nombre Base de Datos:'); ?></label>
								    <div class="col-sm-10">
								    	<input type="text" class="form-control" id="db_name" name="db_name" value="" placeholder="">
								    </div>
								</div>
								<div class="form-group">
								    <label for="db_username" class="col-sm-2 control-label"><?php print SB_Text::_('Usuario:'); ?></label>
								    <div class="col-sm-10">
								    	<input type="text" class="form-control" id="db_username" name="db_username" value="" placeholder="">
								    </div>
								</div>
								<div class="form-group">
								    <label for="db_pwd" class="col-sm-2 control-label"><?php print SB_Text::_('Constrase&ntilde;a:'); ?></label>
								    <div class="col-sm-10">
								    	<input type="text" class="form-control" id="db_pwd" name="db_pwd" value="" placeholder="">
								    </div>
								</div>
								<p>
									<a id="btn-check-connection" href="javascript:;" class="btn btn-primary">
										<?php print SB_Text::_('Verificar conexion'); ?>
									</a>
								</p>
				      		</div>
				    	</div>
				  	</div><!-- end id="panel-database" -->
				  	<div id="panel-admin-cfg" class="panel panel-default">
				    	<div class="panel-heading" role="tab" id="headingThree">
				      		<h4 class="panel-title"><?php print SB_Text::_('Administracion')?></h4>
				    	</div>
				    	<div id="collapse-admin-cfg" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
				      		<div class="panel-body">
				      			<div style="display:none">
					    			<div class="form-group">
									    <label for="base_url" class="col-sm-2 control-label"><?php print SB_Text::_('URL Instalacion:'); ?></label>
									    <div class="col-sm-10">
									    	<input type="text" class="form-control" id="base_url" name="base_url" value="<?php print $base_url; ?>" placeholder="">
									    </div>
									</div>
					    		</div>
				      			<?php print SB_Text::_('Ingrese una contrase&ntilde;a para el usuario de administracion'); ?>
				      			<div class="form-group">
								    <label for="root_pwd" class="col-sm-2 control-label"><?php print SB_Text::_('Contrase&ntilde;a:'); ?></label>
								    <div class="col-sm-10">
								    	<input type="password" class="form-control" id="root_pwd" name="root_pwd" value="" placeholder="">
								    </div>
								</div>
					      		<p>
					      			<button type="submit" class="btn btn-primary"><?php print SB_Text::_('Terminado'); ?></button>
					      		</p>
				      		</div>
				    	</div>
				  	</div>
				</div><!-- end id="accordion" -->
			</form>
		</div><!-- end id="content" -->
	</div>
</div>
</body>
</html>