<?php
$base_dir = dirname(dirname(__FILE__));
$cfg_file = $base_dir . DIRECTORY_SEPARATOR . 'config.php';
if( !file_exists($cfg_file) )
{
	header('Location: index.php');die();
}
define('LT_INSTALL', 1);
define('CFG_FILE', basename($cfg_file));
require_once $base_dir . DIRECTORY_SEPARATOR . 'init.php';
try 
{
	$root_pwd	= SB_Session::getVar('root_pwd');
	$dbh 		= SB_Factory::getDbh();
	$cdate 		= date('Y-m-d H:i:s');
	$sql 		= file_get_contents('database.sql');
	$queries 	= array_map('trim', explode(";\n", $sql));
	foreach($queries as $query)
	{
		if( empty($query) ) continue;
		$dbh->Query($query);
	}
	$query = "SELECT * FROM users WHERE username = 'root' LIMIT 1";
	//##check if root user already exists
	if( !$dbh->Query($query) )
	{
		$root_user = array(
				'first_name'	=> 'Super',
				'last_name'		=> 'Root',
				'username'		=> 'root',
				'pwd'			=> md5($root_pwd),
				'status'		=> 'enabled',
				'role_id'		=> 0,
				'creation_date'	=> $cdate
		);
		$dbh->Insert('users', $root_user);
	}
	
	$roles = array(
			array( 'label' => 'Admin', 'key' => 'admin'),
			array( 'label' => 'User', 'key' => 'user'),
			array( 'label' => 'Guest', 'key' => 'guest'),
	);
	
	foreach($roles as $role)
	{
		if( !$dbh->Query('SELECT * FROM user_roles WHERE role_key = "'.$role['key'].'" LIMIT 1') )
		{
			$role_data = array(
					'role_name'			=> $role['label'],
					'role_key'				=> $role['key'],
					'creation_date'		=> date('Y-m-d H:i:s')
			);
			$dbh->Insert('user_roles', $role_data);
		}
	}
	$permissions = array(
			array(
					'permission'	=> 'manage_modules',
					'label'			=> SB_Text::_('Administrar Modulos'),
					'last_modification_date'	=> $cdate,
					'creation_date'				=> $cdate
			),
			array(
					'permission'	=> 'enable_module',
					'label'			=> SB_Text::_('Habilitar Modulo'),
					'last_modification_date'	=> $cdate,
					'creation_date'				=> $cdate
			),
			array(
					'permission'	=> 'disable_module',
					'label'			=> SB_Text::_('Deshabilitar Modulo'),
					'last_modification_date'	=> $cdate,
					'creation_date'				=> $cdate
			),
			array(
					'permission'	=> 'manage_backend',
					'label'			=> SB_Text::_('Administrar Backend'),
					'last_modification_date'	=> $cdate,
					'creation_date'				=> $cdate
			),
			array(
					'permission'	=> 'create_role_admin',
					'label'			=> SB_Text::_('Crear Rol Admin'),
					'last_modification_date'	=> $cdate,
					'creation_date'				=> $cdate
			),
			array(
					'permission'	=> 'create_role_user',
					'label'			=> SB_Text::_('Crear Rol Usuario'),
					'last_modification_date'	=> $cdate,
					'creation_date'				=> $cdate
			),
			array(
					'permission'	=> 'create_role_guest',
					'label'			=> SB_Text::_('Crear Rol Invitado'),
					'last_modification_date'	=> $cdate,
					'creation_date'				=> $cdate
			),
	);
	$local_permissions = sb_get_permissions(false);
	foreach($permissions as $perm)
	{
		if( in_array($perm['permission'], $local_permissions) ) continue;
		$dbh->Insert('permissions', $perm);
	}
	$dbh->Close();
	SB_Session::unsetVar('root_pwd');
}
catch(Exception $e)
{
	header('Location: index.php');die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title></title>
	<meta charset="utf-8" />
	<link href="../js/bootstrap-3.3.5/css/bootstrap.min.css" rel="stylesheet" />
	<link href="../js/bootstrap-3.3.5/css/bootstrap-theme.min.css" rel="stylesheet" />
	<script src="../js/jquery.min.js"></script>
	<script src="../js/bootstrap-3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid">
	<div class="row">
		<div id="content" class="col-md-10 col-md-offset-1">
			<div class="jumbotron">
				<h1><?php print SB_Text::_('Instalaci&oacute;n completada.'); ?></h1>
				<p>
					<?php print SB_Text::_('Usuario:'); ?> root<br/>
					<?php print SB_Text::_('Contrase&ntilde;a:'); ?> [<?php print SB_Text::_('su contrase&ntilde;a')?>]
				</p>
			</div>
			<p class="text-center">
				<a href="<?php print SB_Route::_('admin/index.php'); ?>" class="btn btn-primary"><?php print SB_Text::_('Acceder al backend')?></a>
			</p>
		</div>
	</div>
</div>
</body>
</html>