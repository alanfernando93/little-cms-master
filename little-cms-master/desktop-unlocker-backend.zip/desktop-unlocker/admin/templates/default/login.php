<?php
defined('LT_ADMIN') or die();
?>
<!doctype html>
<html>
<head>
	<title>Little CMS - Login</title>
	<link rel="stylesheet" href="<?php print TEMPLATE_URL ?>/css/login.css" />
</head>
<body>
<div id="container">
	<section class="login">
		<div class="titulo">Backend Login</div>
		<form id="login_form" name="login_form" action="<?php print SB_Route::_('login.php'); ?>" method="post" enctype="application/x-www-form-urlencoded">
			<input type="hidden" name="mod" value="users" />
			<input type="hidden" name="task" value="do_login" />
	    	<input type="text" name="username" required title="Username required" placeholder="Usuario" data-icon="U" />
	        <input type="password" name="pwd" required title="Password required" placeholder="Password" data-icon="x" />
	        <p style="text-align:center;">
	        	<img src="<?php print BASEURL; ?>/captcha.php?time=<?php print time(); ?>" alt="" />
	        	<input type="text" name="captcha" value="" autocomplete="off" />
	        </p>
	        <div class="olvido">
	        	<div class="col"><a href="#" title="Registro">Registro</a></div>
	            <div class="col"><a href="#" title="Recuperar Password">Olvido su Password?</a></div>
	        </div>
	        <button type="submit" style="display:none;">Login</button>
	        <a href="javascript:;" class="enviar" onclick="document.login_form.submit();">Login</a>
	    </form><br/>
	 	<?php SB_MessagesStack::ShowMessages(); ?>   
	</section>
</div>
</body>
</html>