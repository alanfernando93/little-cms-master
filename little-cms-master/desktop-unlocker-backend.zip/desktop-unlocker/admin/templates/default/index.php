<?php
require_once 'header.php';
?>
	<div id="content">
		<div class="container"><?php SB_MessagesStack::ShowMessages(); ?></div>
		<?php sb_show_module($mod); ?>
	</div><!-- end id="content" -->
<?php require_once 'footer.php';  ?>