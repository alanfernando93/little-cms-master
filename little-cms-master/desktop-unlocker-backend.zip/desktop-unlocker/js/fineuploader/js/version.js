/*global qq */
qq.version = "5.2.2";
